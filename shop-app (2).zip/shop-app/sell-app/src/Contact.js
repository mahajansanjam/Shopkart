
import React from 'react'

function Contact() {
  return (
    <div>
        <div class="d-flex">
      <div class="card" >
  <img src="https://img.freepik.com/free-psd/poster-chinese-food-template_23-2148679556.jpg?w=2000" class="card-img-top" height="500px" width="500px" alt="..."/>
  <div class="card-body">
    <p class="card-text" style ={{color:"blue"}}>Chinese food portable</p>
    <a href="#" class="btn btn-primary"style={{color:"blue"}}> go somewhere</a>
  </div>
</div>

<div class="card" >
  <img src="https://c4.wallpaperflare.com/wallpaper/234/543/684/food-pizza-wallpaper-preview.jpg" class="card-img-top" height="500px" width="500px" alt="..."/>
  <div class="card-body">
    <p class="card-text" style ={{color:"red"}}> pizza aviable here</p>
    <a href="#" class="btn btn-primary"style={{color:"blue"}}> go somewhere</a>
  </div>
</div>

<div class="card" >
  <img src="https://images.unsplash.com/photo-1571091718767-18b5b1457add?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8OXx8YnVyZ2VyfGVufDB8fDB8fHww&w=1000&q=80" class="card-img-top" height="500px" width="500px" alt="..."/>
  <div class="card-body">
    <p class="card-text" style ={{color:"green"}}> Burger veg and non veg</p>
    <a href="#" class="btn btn-primary"style={{color:"blue"}}> go somewhere</a>
  </div>
</div>
</div>

<div class="d-flex">
      <div class="card" >
  <img src="https://e0.pxfuel.com/wallpapers/389/311/desktop-wallpaper-food-graphy-pizza.jpg" class="card-img-top" height="500px" width="500px" alt="..."/>
  <div class="card-body">
    <p class="card-text" style ={{color:"green"}}>pizza prtable </p>
    <a href="#" class="btn btn-primary"style={{color:"blue"}}> go somewhere</a>
  </div>
</div>


<div class="card" >
  <img src="https://c4.wallpaperflare.com/wallpaper/1017/647/742/food-pizza-cheese-tomatoes-olives-hd-wallpaper-preview.jpg" class="card-img-top" height="500px" width="500px" alt="..."/>
  <div class="card-body">
    <p class="card-text" style ={{color:"blue"}}> pizza variaty</p>
    <a href="#" class="btn btn-primary"style={{color:"blue"}}> go somewhere</a>
  </div>
</div>

<div class="card" >
  <img src="https://images2.alphacoders.com/970/thumb-1920-97040.jpg" class="card-img-top" height="500px" width="500px" alt="..."/>
  <div class="card-body">
    <p class="card-text" style ={{color:"red"}}>  veg  pizza</p>
    <a href="#" class="btn btn-primary"style={{color:"blue"}}> go somewhere</a>
  </div>
</div>
</div>



<div class="d-flex">
      <div class="card" >
  <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSkfB7nt2nKBsMgosnySwylmhxI073q8WfRyeIkaMw7ew&usqp=CAU&ec=48665699" class="card-img-top" height="500px" width="500px" alt="..."/>
  <div class="card-body">
    <p class="card-text" style ={{color:"green"}}>cheese pizaa  </p>
    <a href="#" class="btn btn-primary"style={{color:"blue"}}> go somewhere</a>
  </div>
</div>


<div class="card" >
  <img src="https://i.pinimg.com/originals/41/ab/16/41ab165a34d05f715c9764efcdc09e8a.jpg" class="card-img-top" height="500px" width="500px" alt="..."/>
  <div class="card-body">
    <p class="card-text" style ={{color:"blue"}}> single cheese  pizza variaty</p>
    <a href="#" class="btn btn-primary"style={{color:"blue"}}> go somewhere</a>
  </div>
</div>

<div class="card" >
  <img src="https://e0.pxfuel.com/wallpapers/203/589/desktop-wallpaper-pizza-high-quality-high-definition-high-cool-pizza.jpg" class="card-img-top" height="500px" width="500px" alt="..."/>
  <div class="card-body">
    <p class="card-text" style ={{color:"red"}}>  double cheese   veg  pizza</p>
    <a href="#" class="btn btn-primary"style={{color:"blue"}}> go somewhere</a>
  </div>
</div>
</div>


<div class="d-flex">
      <div class="card" >
  <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSkfB7nt2nKBsMgosnySwylmhxI073q8WfRyeIkaMw7ew&usqp=CAU&ec=48665699" class="card-img-top" height="500px" width="500px" alt="..."/>
  <div class="card-body">
    <p class="card-text" style ={{color:"green"}}>cheese pizaa  </p>
    <a href="#" class="btn btn-primary"style={{color:"blue"}}> go somewhere</a>
  </div>
</div>


<div class="card" >
  <img src="https://img.freepik.com/free-photo/close-up-italian-pizza-about-cheese-it-stick-selective-focus-generative-ai_1258-153063.jpg?w=2000" class="card-img-top" height="500px" width="500px" alt="..."/>
  <div class="card-body">
    <p class="card-text" style ={{color:"blue"}}>  spicy cheese  pizza variaty</p>
    <a href="#" class="btn btn-primary"style={{color:"blue"}}> go somewhere</a>
  </div>
</div>

<div class="card" >
  <img src="https://media.istockphoto.com/id/1303119992/photo/pizza_margerita.jpg?s=612x612&w=0&k=20&c=0HZZMC10ySBYvMVAKUNzknkQ1E74q8NKwTV5_K6WK6M=" class="card-img-top" height="500px" width="500px" alt="..."/>
  <div class="card-body">
    <p class="card-text" style ={{color:"red"}}>  double spicy cheese   veg  pizza</p>
    <a href="#" class="btn btn-primary"style={{color:"blue"}}> go somewhere</a>
  </div>
</div>
</div>



<div class="d-flex">
      <div class="card" >
  <img src="https://www.pngitem.com/pimgs/m/54-545087_pizza-hd-png-download.png" class="card-img-top" height="500px" width="500px" alt="..."/>
  <div class="card-body">
    <p class="card-text" style ={{color:"green"}}> makhan cheese pizaa  </p>
    <a href="#" class="btn btn-primary"style={{color:"blue"}}> go somewhere</a>
  </div>
</div>


<div class="card" >
  <img src="https://p4.wallpaperbetter.com/wallpaper/698/474/361/dinner-food-pie-pizza-wallpaper-preview.jpg" class="card-img-top" height="500px" width="500px" alt="..."/>
  <div class="card-body">
    <p class="card-text" style ={{color:"blue"}}> single spicy cheese  pizza variaty</p>
    <a href="#" class="btn btn-primary"style={{color:"blue"}}> go somewhere</a>
  </div>
</div>

<div class="card" >
  <img src="https://images.wallpapersden.com/image/download/pizza-vegetables-baked-goods_amZmamiUmZqaraWkpJRmbmdlrWZlbWU.jpg" class="card-img-top" height="500px" width="500px" alt="..."/>
  <div class="card-body">
    <p class="card-text" style ={{color:"red"}}>  double spicy cheese   veg  pizza</p>
    <a href="#" class="btn btn-primary"style={{color:"blue"}}> go somewhere</a>
  </div>
</div>
</div>



<div class="d-flex">
      <div class="card" >
  <img src="https://www.imagemela.com/uploads/products/814/1143/imagemela-114065.jpg" class="card-img-top" height="500px" width="500px" alt="..."/>
  <div class="card-body">
    <p class="card-text" style ={{color:"green"}}>cheese and spicy pizaa  </p>
    <a href="#" class="btn btn-primary"style={{color:"blue"}}> go somewhere</a>
  </div>
</div>


<div class="card" >
  <img src="https://www.shutterstock.com/image-photo/meat-lover-pizza-served-restaurant-260nw-1709540761.jpg" class="card-img-top" height="500px" width="500px" alt="..."/>
  <div class="card-body">
    <p class="card-text" style ={{color:"blue"}}> single and spicy cheese  pizza variaty</p>
    <a href="#" class="btn btn-primary"style={{color:"blue"}}> go somewhere</a>
  </div>
</div>

<div class="card" >
  <img src="https://www.pngkit.com/png/full/9-92696_classic-pizza-garden-fresh-pizza-hd.png" class="card-img-top" height="500px" width="500px" alt="..."/>
  <div class="card-body">
    <p class="card-text" style ={{color:"red"}}>  double  and spicy cheese   veg  pizza</p>
    <a href="#" class="btn btn-primary"style={{color:"blue"}}> go somewhere</a>
  </div>
</div>
</div>



<div class="d-flex">
      <div class="card" >
  <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQSW8Qpcod2QCVc2XHJxX5YarNuvi5yxdCtyD7nS-2zz3f_jC8z5Nv7dNGXzt3zm_27tQNc4RXW5o8&usqp=CAU&ec=48665699" class="card-img-top" height="500px" width="500px" alt="..."/>
  <div class="card-body">
    <p class="card-text" style ={{color:"green"}}>extra  large  pizaa  and spicy </p>
    <a href="#" class="btn btn-primary"style={{color:"blue"}}> go somewhere</a>
  </div>
</div>


<div class="card" >
  <img src="https://www.pngkit.com/png/full/9-92696_classic-pizza-garden-fresh-pizza-hd.png" class="card-img-top" height="500px" width="500px" alt="..."/>
  <div class="card-body">
    <p class="card-text" style ={{color:"blue"}}> single cheese spicy  pizza variaty</p>
    <a href="#" class="btn btn-primary"style={{color:"blue"}}> go somewhere</a>
  </div>
</div>

<div class="card" >
  <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTYe8myGvFcokOhgFQ7G60Klog-E5HPX6nI_1mT8QRo0wstAnZD0t34I5kw_UMRT0swi9GKju5-We0&usqp=CAU&ec=48665699" class="card-img-top" height="500px" width="500px" alt="..."/>
  <div class="card-body">
    <p class="card-text" style ={{color:"red"}}>  double cheese  spicy  veg  pizza</p>
    <a href="#" class="btn btn-primary"style={{color:"blue"}}> go somewhere</a>
  </div>
</div>
</div>


<div class="d-flex">
      <div class="card" >
  <img src="https://www.hubpng.com/files/preview/1280x753/11574038637pr9baux3hh2pwumckkt8ousjzzmsuiubirlfr9xe5tqzlzirsn8fr0j6xf1ffterot8qziagwrko46m1ulirw49sgnwzxhpzm6ke.png" class="card-img-top" height="500px" width="500px" alt="..."/>
  <div class="card-body">
    <p class="card-text" style ={{color:"green"}}>  stuffing and mindy cheese pizaa  </p>
    <a href="#" class="btn btn-primary"style={{color:"blue"}}> go somewhere</a>
  </div>
</div>


<div class="card" >
  <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSYr3TOdG00x9-2lUBpqBjR44aZI-64CMDn_rpdr3ZDUQ&usqp=CAU&ec=48665699" class="card-img-top" height="500px" width="500px" alt="..."/>
  <div class="card-body">
    <p class="card-text" style ={{color:"blue"}}>   sweetcorn pizza variaty</p>
    <a href="#" class="btn btn-primary"style={{color:"blue"}}> go somewhere</a>
  </div>
</div>

<div class="card" >
  <img src="https://w0.peakpx.com/wallpaper/801/891/HD-wallpaper-food-pizza.jpg" class="card-img-top" height="500px" width="500px" alt="..."/>
  
  <div class="card-body">
    <p class="card-text" style ={{color:"red"}}>  double  sweetcorn cheese   veg  pizza</p>
    <a href="#" class="btn btn-primary"style={{color:"blue"}}> go somewhere</a>
  </div>
</div>
</div>

<div id="carouselExample" class="carousel slide">
  <div class="carousel-inner">
    <div class="carousel-item active">
      <img src="https://images.pexels.com/photos/1146760/pexels-photo-1146760.jpeg?cs=srgb&dl=pexels-kristina-paukshtite-1146760.jpg&fm=jpg" class="d-block w-100" height="500px" width="500px" alt="..."/>
    </div>
    <div class="carousel-item">
      <img src="https://rare-gallery.com/uploads/posts/518205-food-pizza.jpg" class="d-block w-100" height="500px" width="500px" alt="..."/>
    </div>
    <div class="carousel-item">
      <img src="https://www.wallpapers4u.org/wp-content/uploads/pizza_batch_stuffing_pepper_20718_1920x1080.jpg" class="d-block w-100"  height="500px" width="500px" alt="..."/>
    </div>
  </div>
  <button class="carousel-control-prev" type="button" data-bs-target="#carouselExample" data-bs-slide="prev">
    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
    <span class="visually-hidden">Previous</span>
  </button>
  <button class="carousel-control-next" type="button" data-bs-target="#carouselExample" data-bs-slide="next">
    <span class="carousel-control-next-icon" aria-hidden="true"></span>
    <span class="visually-hidden">Next</span>
  </button>
</div>


<div style={{backgroundColor:"grey"}} className="text-center"/>
        <center><h1 style ={{color:"red"}}>My Contact Detail</h1></center><hr/>
        <div style={{display:"flex"}} className="container">
            <div className="col-lg-6 text-center">
                <h1 style ={{color:"blue"}}>sanjam Mahjan</h1>
                <h1 style ={{color:"red"}}>Mail to:mahajansanjam@gmail.com</h1>
                <h1 style ={{color:"green"}}>9779880636</h1>
                <img src="https://cdn-icons-png.flaticon.com/128/4782/4782351.png"height="50px"/>
                <img src="https://cdn-icons-png.flaticon.com/128/5968/5968534.png"height="50px"/>
                <img src="https://cdn-icons-png.flaticon.com/128/145/145802.png"height="50px"/> 
                <img src="https://cdn-icons-png.flaticon.com/128/2111/2111463.png"height="50px"/>
                

        </div>
        <div className="col-lg-6 text-center">
        <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d13540.02035526855!2d75.32955654999999!3d31.960758650000002!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x391bedb098174a4f%3A0x6708c79c92ac98b0!2sBurger%20Hut%20-%20Dhariwal!5e0!3m2!1sen!2sin!4v1675245666027!5m2!1sen!2sin" width="500" height="450"></iframe>
        </div>
</div>

<div class="row">
        <form class="row g-3 needs-validation" novalidate="">
      <div data-aos="fade-up" class="col-md-4 position-relative">
        <label for="validationTooltip01" class="form-label">First name</label>
        <input type="text" class="form-control" id="validationTooltip01" value="" placeholder="sanjam" required=""/>
        <div class="valid-tooltip">
          Looks good!
        </div>
      </div>
      <div data-aos="fade-up" class="col-md-4 position-relative">
        <label for="validationTooltip02" class="form-label">Last name</label>
        <input type="text" class="form-control" id="validationTooltip02" value="" placeholder="mahajan" required=""/>
        <div class="valid-tooltip">
          Looks good!
        </div>
      </div>
      <div data-aos="fade-up" class="col-md-4 position-relative">
        <label for="validationTooltipUsername" class="form-label">Username</label>
        <div class="input-group has-validation">
          <span class="input-group-text" id="validationTooltipUsernamePrepend">@</span>
          <input type="text" class="form-control" id="validationTooltipUsername" aria-describedby="validationTooltipUsernamePrepend" required=""/>
          <div class="invalid-tooltip">
            Please choose a unique and valid username.
          </div>
        </div>
      </div>
      <div data-aos="fade-up" class="col-md-6 position-relative">
        <label for="validationTooltip03" class="form-label">contact no.</label>
        <input type="text" class="form-control" id="validationTooltip03" required=""/>
        <div class="invalid-tooltip">
          Please enter valid number
        </div>
      </div>
      <div data-aos="fade-up" class="col-md-3 position-relative">
        <label for="validationTooltip04" class="form-label">City</label>
        <select class="form-select" id="validationTooltip04" required="">
          <option selected="" disabled="" value="">Choose...</option>
          <option>dhariwal</option>
          <option>chandhigarh</option>
          <option>noida</option>
          <option>delhi</option>
          <option>gurdaspur</option>
          <option>Bathinda</option>
          <option>karantaka</option>
          <option>new york</option>
          <option>usa</option>
        </select>
        <div data-aos="fade-up"class="invalid-tooltip">
          Please select a valid city.
        </div>
      </div>
      <div class="col-md-3 position-relative">
        <label for="validationTooltip05" class="form-label">Pin code</label>
        <input type="text" class="form-control" id="validationTooltip05" required=""/>
        <div class="invalid-tooltip">
          Please provide a valid pin code.
        </div>
      </div>
      <div class="col-12">
        <button class="btn btn-primary" type="submit">Submit form</button>
      </div>
      </form></div>
    </div>










  )
}

export default Contact
