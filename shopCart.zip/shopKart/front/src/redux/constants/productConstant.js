

export const GET_PRODUCTS_SUCCESS ='getproductsSuccess';
export const GET_PRODUCTS_FAIL ='getproductsFail';

export const GET_PRODUCT_DETAILS_REQUEST = 'getproductDetailsRequest';
export const GET_PRODUCTS_DETAILS_SUCCESS= 'getproductDetailsSuccess';
export const GET_PRODUCT_DETAILS_FAIL= 'getproductDetailsFail';
export const GET_PRODUCT_DETAILS_RESET= 'getproductDetailsReset';
