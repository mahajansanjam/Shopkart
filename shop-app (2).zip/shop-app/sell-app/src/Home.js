
import React from 'react'

function Home() {
  return (
    <div>
        <div class="d-flex">
      <div  className="card">
  <img src="https://indian-retailer.s3.ap-south-1.amazonaws.com/s3fs-public/2022-03/The%20New%20Shop.jpg" height="500px" width="500px" class="card-img-top" alt="..."/>
  <div className="card-body">
    <p className="card-text" style ={{color:"red"}}>Different types of section</p>
    <a href="#" class="btn btn-primary"style={{color:"blue"}}> go somewhere</a>
  </div>
</div>

<div className="card">
  <img src="https://i.pinimg.com/originals/5a/ab/bd/5aabbd2eec8c9bf6caa039b6769dde42.png" height="500px" width="500px" class="card-img-top" alt="..."/>
  <div className="card-body">
    <p className="card-text" style ={{color:"yellow"}}>Some types of section</p>
    <a href="#" class="btn btn-primary"style={{color:"blue"}}> go somewhere</a>
  </div>
</div>

<div className="card">
  <img src="https://i.redd.it/tqdym1duhij01.jpg" height="500px" width="500px" class="card-img-top" alt="..."/>
  <div className="card-body">
    <p className="card-text" style ={{color:"blue"}}>All types of section</p>
    <a href="#" class="btn btn-primary"style={{color:"blue"}}> go somewhere</a>
  </div>
</div>
</div>

<div className="card">
  <img src="https://media.timeout.com/images/101705151/image.jpg" height="500px" width="500px" class="card-img-top" alt="..."/>
  <div className="card-body">
    <p className="card-text" style ={{color:"red"}}>Men  types of section</p>
    <a href="#" class="btn btn-primary"style={{color:"blue"}}> go somewhere</a>
  </div>
</div>


<div id="carouselExampleIndicators" class="carousel slide">
  <div class="carousel-indicators">
    <button type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide-to="0" class="active" aria-current="true" aria-label="Slide 1"></button>
    <button type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide-to="1" aria-label="Slide 2"></button>
    <button type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide-to="2" aria-label="Slide 3"></button>
  </div>
  <div class="carousel-inner">
    <div class="carousel-item active">
      <img src="https://www.chameleonjohn.com/blog/wp-content/uploads/2014/05/fashion-store.jpg" class="d-block w-100" height="400px" width="400px" alt="..."/>
    </div>
    <div class="carousel-item">
      <img src="https://th.bing.com/th/id/R.042dd02eb42357e602c47fb6bd01d4b7?rik=tbeQ5Xh7%2f1T6Gg&riu=http%3a%2f%2fmedia.architecturaldigest.com%2fphotos%2f56c647cf5ef3a2f746a41ebf%2fmaster%2fpass%2fParis-Fashion-Shops-03.jpg&ehk=hDn4CinYGI1Y9Da1a9TJSyk1GLG04jmnwoqLxSWR8xs%3d&risl=&pid=ImgRaw&r=0" class="d-block w-100" height="500px" width="500px" alt="..."/>
    </div>
    <div class="carousel-item">
      <img src="https://meatmanagement.com/wp-content/uploads/2019/06/IMG_4657.jpg" class="d-block w-100"  height="400px"  width="400px"alt="..."/>
    </div>
  </div>
  <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide="prev">
    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
    <span class="visually-hidden">Previous</span>
  </button>
  <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide="next">
    <span class="carousel-control-next-icon" aria-hidden="true"></span>
    <span class="visually-hidden">Next</span>
  </button>
</div>

<div class="d-flex">
      <div className="card">
  <img src="https://coresites-cdn-adm.imgix.net/mpora_new/wp-content/uploads/2015/12/iStock_000001940126_Medium.jpg?fit=crop&w=1678&h=1144" height="500px" width="500px" class="card-img-top" alt="..."/>
  <div className="card-body">
    <p className="card-text" style ={{color:"yellow"}}>Special types of hill climbing section</p>
    <a href="#" class="btn btn-primary"style={{color:"blue"}}> go somewhere</a>
  </div>
</div>

<div className="card">
  <img src="https://th.bing.com/th/id/R.22961adf24968e0784e10f9454a39a0a?rik=%2fsT6IRWrCAm9zg&riu=http%3a%2f%2fwww.slausonsupermallinc.com%2fmap-images-new%2fH-01.jpg&ehk=PS%2fktGjvHSXcWLP8REsswT%2bHZRHoyt3Ch16%2fVnXXy10%3d&risl=&pid=ImgRaw&r=0" height="500px" width="500px" class="card-img-top" alt="..."/>
  <div className="card-body">
    <p className="card-text" style ={{color:"green"}}> Shoes department </p>
    <a href="#" class="btn btn-primary"style={{color:"blue"}}> go somewhere</a>
  </div>
</div>

<div className="card">
  <img src="https://tse1.mm.bing.net/th/id/OIP.vxmef0IIOaloAICP_lSn6wHaHa?pid=ImgDet&rs=1" height="500px" width="500px" class="card-img-top" alt="..."/>
  <div className="card-body">
    <p className="card-text" style ={{color:"blue"}}>Gucci shoes section</p>
    <a href="#" class="btn btn-primary"style={{color:"blue"}}> go somewhere</a>
  </div>
</div>
</div>

<div class="d-flex">
      <div className="card">
  <img src="https://www.jiomart.com/images/product/original/rvyybpx9re/brown-fox-mesh-running-shoes-cricket-shoes-badminton-shoes-volly-ball-shoes-sports-shoes-for-mens-and-boys-running-shoes-for-men-canvas-shoes-for-men-running-shoes-for-men-grey-product-images-rvyybpx9re-0-202209241732.jpg" height="500px" width="500px" class="card-img-top" alt="..."/>
  <div className="card-body">
    <p className="card-text" style ={{color:"purple"}}>Sports meet  shoes</p>
    <a href="#" class="btn btn-primary"style={{color:"blue"}}> go somewhere</a>
  </div>
</div>

<div className="card">
  <img src="https://rukminim1.flixcart.com/image/850/850/kt39jm80/shoe/p/q/v/8-mdl-off-black-white-franxtar-white-black-original-imag6gh73ykcqt6g.jpeg?q=90" height="500px" width="500px" class="card-img-top" alt="..."/>
  <div className="card-body">
    <p className="card-text" style ={{color:"yellow"}}> special meets shoes </p>
    <a href="#" class="btn btn-primary"style={{color:"blue"}}> go somewhere</a>
  </div>
</div>

<div className="card">
  <img src="https://rukminim1.flixcart.com/image/850/850/l2ghgnk0/shopsy-shoe/n/5/d/6-1010-6-rkm-shoes-grey-original-imagdsqzzefuyvz2.jpeg?q=90" height="500px" width="500px" class="card-img-top" alt="..."/>
  <div className="card-body">
    <p className="card-text" style ={{color:"red"}}>Gucci special special  shoes section</p>
    <a href="#" class="btn btn-primary"style={{color:"blue"}}> go somewhere</a>
  </div>
</div>
</div>



<div class="d-flex">
      <div className="card">
  <img src="https://cdn.shopify.com/s/files/1/0607/6678/1671/products/FIRST_11G-787_BLK-MATTLIC.BLU.jpg?v=1670326503" height="500px" width="500px" class="card-img-top" alt="..."/>
  <div className="card-body">
    <p className="card-text" style ={{color:"red"}}> lettest meets boat </p>
    <a href="#" class="btn btn-primary"style={{color:"blue"}}> go somewhere</a>
  </div>
</div>

<div className="card">
  <img src="https://5.imimg.com/data5/YC/GV/XN/ANDROID-83761084/product-jpeg-500x500.jpg" height="500px" width="500px" class="card-img-top" alt="..."/>
  <div className="card-body">
    <p className="card-text" style ={{color:"green"}}> try sports meet shoes </p>
    <a href="#" class="btn btn-primary"style={{color:"blue"}}> go somewhere</a>
  </div>
</div>

<div className="card">
  <img src="https://rukminim2.flixcart.com/image/450/500/xif0q/shoe/j/q/n/8-mrj2100-8-aadi-white-black-grey-original-imagn8yk5hfq7vnh.jpeg?q=90&crop=false" height="500px" width="500px" class="card-img-top" alt="..."/>
  <div className="card-body">
    <p className="card-text" style ={{color:"blue"}}> lets try new thing</p>
    <a href="#" class="btn btn-primary"style={{color:"blue"}}> go somewhere</a>
  </div>
</div>
</div>


<div class="d-flex">
      <div className="card">
  <img src="https://assets.myntassets.com/dpr_1.5,q_60,w_400,c_limit,fl_progressive/assets/images/15778982/2021/10/25/705a529a-97a1-4b60-bdf2-64bab0d151031635184404737ProvogueMenBlackSolidFormalDebys1.jpg" height="500px" width="500px" class="card-img-top" alt="..."/>
  <div className="card-body">
    <p className="card-text" style ={{color:"red"}}>   good shoes for running </p>
    <a href="#" class="btn btn-primary"style={{color:"blue"}}> go somewhere</a>
  </div>
</div>

<div className="card">
  <img src="http://cdn.shopify.com/s/files/1/1417/8980/products/LeatherSoleShoesforMen.jpg?v=1664884575" height="500px" width="500px" class="card-img-top" alt="..."/>
  <div className="card-body">
    <p className="card-text" style ={{color:"green"}}> good condition and  expensive  shoes </p>
    <a href="#" class="btn btn-primary"style={{color:"blue"}}> go somewhere</a>
  </div>
</div>

<div className="card">
  <img src="https://imgeng.jagran.com/images/2023/mar/Best%20formal%20shoes1677844989770.jpg" height="500px" width="500px" class="card-img-top" alt="..."/>
  <div className="card-body">
    <p className="card-text" style ={{color:"blue"}}> more expensive for men and boys</p>
    <a href="#" class="btn btn-primary"style={{color:"blue"}}> go somewhere</a>
  </div>
</div>
</div>




<div className="card">
  <img src="https://navbharattimes.indiatimes.com/photo/msid-95476503,imgsize-79510/pic.jpg" height="500px" width="500px" class="card-img-top" alt="..."/>
  <div className="card-body">
    <p className="card-text" style ={{color:"green"}}> all types of shoes </p>
    <a href="#" class="btn btn-primary"style={{color:"blue"}}> go somewhere</a>
  </div>
</div>

<div className="card">
  <img src="https://www.jiomart.com/images/product/500x630/rvplqqrocy/dunkaston-brown-formal-shoes-for-men-product-images-rvplqqrocy-0-202211021425.jpg" height="500px" width="500px" class="card-img-top" alt="..."/>
  <div className="card-body">
    <p className="card-text" style ={{color:"blue"}}> must sees shoes</p>
    <a href="#" class="btn btn-primary"style={{color:"blue"}}> go somewhere</a>
  </div>
</div>


<div class="d-flex">
      <div className="card">
  <img src="https://images.meesho.com/images/products/54696103/cqsfz_512.jpg" height="500px" width="500px" class="card-img-top" alt="..."/>
  <div className="card-body">
    <p className="card-text" style ={{color:"red"}}>  more expensive shoes for ladies </p>
    <a href="#" class="btn btn-primary"style={{color:"blue"}}> go somewhere</a>
  </div>
</div>

<div className="card">
  <img src="https://images-cdn.ubuy.co.in/634e7b7f272d59090c5a12fa-hemlock-flat-shoes-mens-mens-casual.jpg" height="500px" width="500px" class="card-img-top" alt="..."/>
  <div className="card-body">
    <p className="card-text" style ={{color:"green"}}> good condition and  expensive  shoes </p>
    <a href="#" class="btn btn-primary"style={{color:"blue"}}> go somewhere</a>
  </div>
</div>

<div className="card">
  <img src="https://m.media-amazon.com/images/I/71D9ImsvEtL._AC_UY1000_.jpg" height="500px" width="500px" class="card-img-top" alt="..."/>
  <div className="card-body">
    <p className="card-text" style ={{color:"blue"}}> more expensive for men and boys</p>
    <a href="#" class="btn btn-primary"style={{color:"blue"}}> go somewhere</a>
  </div>
</div>
</div>



<h1 style ={{color:"red"}}>Shopping</h1>
<p style ={{color:"green"}}>A larger commercial zone can be found in many cities, more formally called a central business district, but more commonly called "downtown" in the United States, or the "high street" in Britain, and souks in Arabic speaking areas.

Shopping hubs, or shopping centers, are collections of stores; that is a grouping of several businesses in a compact geographic area. It consists of a collection of retail, entertainment and service stores designed to serve products and services to the surrounding region.

Typical examples include shopping malls, town squares, flea markets and bazaars.

Traditionally, shopping hubs were called bazaars or marketplaces; an assortment of stalls lining streets selling a large variety of goods.[32]

The modern shopping centre is now different from its antecedents, the stores are commonly in individual buildings or compressed into one large structure (usually called Mall in the USA).[33]

The first modern shopping mall in the US was The Country Club Plaza in Kansas City which opened in 1922, from there the first enclosed mall was designed by Victor Gruen and opened in 1956 as Southdale Centre in Edina, Minnesota, a suburb of Minneapolis.

Malls peaked in America in the 1980s-1990s when many larger malls (more than 37,000 sq m in size) were built, attracting consumers from within a 32 km radius with their luxurious department stores.[34]

Different types of malls can be found around the world. Superregional malls are very large malls that contain at least five department stores and 300 shops. This type of mall attracts consumers from a broad radius (up to a 160-km). A regional mall can contain at least two department stores or "anchor stores".[35] One of the biggest malls in the world is the one near Miami, called "Sawgrass Mills Mall": it has 2,370,610 square feet (220,237 m2) of retail selling space, with over 329 retail outlets and name brand discounters.

The smaller malls are often called open-air strip centres or mini-marts and are typically attached to a grocery store or supermarket.

The smaller malls are less likely to include the same features of a large mall such as an indoor concourse, but are beginning to evolve to become enclosed to comply with all weather and customer preferences.[</p>

<h2 style ={{color:"blue"}}>Stores</h2>
<p style ={{color:"red"}}>Stores are divided into multiple categories of stores which sell a selected set of goods or services. Usually they are tiered by target demographics based on the disposable income of the shopper. They can be tiered from cheap to pricey.

Some shops sell secondhand goods. Often the public can also sell goods to such shops. In other cases, especially in the case of a nonprofit shop, the public donates goods to these shops, commonly known as thrift stores in the United States, charity shops in the United Kingdom, or op shops in Australia and New Zealand. In give-away shops goods can be taken for free. In antique shops, the public can find goods that are older and harder to find. Sometimes people are broke and borrow money from a pawn shop using an item of value as collateral. College students are known to resell books back through college textbook bookstores. Old used items are often distributed through surplus stores.

Various types of retail stores that specialize in the selling of goods related to a theme include bookstores, boutiques, candy shops, liquor stores, gift shops, hardware stores, hobby stores, pet stores, pharmacies, sex shops and supermarkets.

Other stores such as big-box stores, hypermarkets, convenience stores, department stores, general stores, dollar stores sell a wider variety of products not horizontally related to each other.</p>

<h3 style ={{color:"red"}}>Home shopping</h3>
<p style ={{color:"blue"}}>Home mail delivery systems and modern technology (such as television, telephones, and the Internet), in combination with electronic commerce, allow consumers to shop from home. There are three main types of home shopping: mail or telephone ordering from catalogs; telephone ordering in response to advertisements in print and electronic media (such as periodicals, TV and radio); and online shopping. Online shopping has completely redefined the way people make their buying decisions; the Internet provides access to a lot of information about a particular product, which can be looked at, evaluated, and comparison-priced at any given time. Online shopping allows the buyer to save the time and expense, which would have been spent traveling to the store or mall. According to technology and research firm Forrester, mobile purchases or mcommerce will account for 49% of ecommerce, or $252 billion in sales, by 2020</p>








</div>

  )
}

export default Home
