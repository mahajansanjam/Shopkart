import React from 'react'

function About() {
  return (
    <div>
        <div class="d-flex">
      <div className="card">
  <img src="https://tse1.mm.bing.net/th?id=OIF.%2bJvh5slCzu5PcynaoPrNJg&pid=ImgDet&rs=1"height="500px" width="500px" alt="..."/>
  <div class="card-body">
    <p class="card-text" style={{Color:"red"}}> fashion  forever types of sections </p>
    <a href="#" class="btn btn-primary"style={{color:"blue"}}> go somewhere</a>
  </div>
</div>

<div className="card">
  <img src="https://tse3.mm.bing.net/th/id/OIP.JJTcjL-S8FffyTxAbSVfrgHaHa?pid=ImgDet&w=853&h=853&rs=1" height="500px" width="500px" alt="..."/>
  <div class="card-body">
    <p class="card-text" style={{Color:"blue"}}> zara  types of sections </p>
    <a href="#" class="btn btn-primary"style={{color:"blue"}}> go somewhere</a>
  </div>
</div>

<div className="card">
  <img src="https://th.bing.com/th/id/R.99ec6607e98dafbf27e52a1cedf9bb8d?rik=doTMsGTW5c3kew&riu=http%3a%2f%2fphotogallery.indiatimes.com%2fphoto%2f51841269.cms&ehk=rVTO0I83iNnOBuZLyeMozq9LuZXYmIn%2f3z7H7%2fCuYoI%3d&risl=&pid=ImgRaw&r=0" height="500px" width="500px" alt="..."/>
  <div class="card-body">
    <p class="card-text" style={{Color:"green"}}> 100% zara types of sections </p>
    <a href="#" class="btn btn-primary"style={{color:"blue"}}> go somewhere</a>
  </div>
</div>
</div>

<div id="carouselExample" class="carousel slide">
  <div class="carousel-inner">
    <div class="carousel-item active">
      <img src="https://n1.sdlcdn.com/imgs/a/k/6/Kumud-Kala-Violet-Designer-Anarkali-SDL472044590-1-07b22.jpg" class="d-block w-100" height ="700px" width="700px" alt="..."/>
    </div>
    <div class="carousel-item">
      <img src="https://n3.sdlcdn.com/imgs/a/l/v/Indian-Wear-Online-Purple-Faux-SDL137897551-1-27658.jpg" class="d-block w-100" height="700px" width="700px" alt="..."/>
    </div>
    <div class="carousel-item">
      <img src="https://i.pinimg.com/736x/fc/52/36/fc52362d67767a168388efcdfeec6c27--salwar-suits-salwar-kameez.jpg" class="d-block w-100" height="700px" width="700px" alt="..."/>
    </div>
  </div>
  <button class="carousel-control-prev" type="button" data-bs-target="#carouselExample" data-bs-slide="prev">
    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
    <span class="visually-hidden">Previous</span>
  </button>
  <button class="carousel-control-next" type="button" data-bs-target="#carouselExample" data-bs-slide="next">
    <span class="carousel-control-next-icon" aria-hidden="true"></span>
    <span class="visually-hidden">Next</span>
  </button>
</div>

<div class="d-flex">
      <div className="card">
  <img src="https://i.pinimg.com/550x/c9/10/5b/c9105b9156484f1f1d2492fb9718ea0c.jpg"height="500px" width="500px" alt="..."/>
  <div class="card-body">
    <p class="card-text" style={{Color:"yellow"}}> Designer saree </p>
    <a href="#" class="btn btn-primary"style={{color:"blue"}}> go somewhere</a>
  </div>
</div>

<div className="card">
  <img src="https://m.media-amazon.com/images/I/91DUhFw1spL._UY550_.jpg" height="500px" width="500px" alt="..."/>
  <div class="card-body">
    <p class="card-text" style={{Color:"red"}}>Diamond saree </p>
    <a href="#" class="btn btn-primary"style={{color:"blue"}}> go somewhere</a>
  </div>
</div>

<div className="card">
  <img src="https://assets.shopkund.com/media/catalog/product/cache/3/image/9df78eab33525d08d6e5fb8d27136e95/a/c/act7326-1-brown-south-indian-saree-in-embroidered-silk-and-viscose-sr20647.jpg" height="500px" width="500px" alt="..."/>
  <div class="card-body">
    <p class="card-text" style={{Color:"blue"}}> golden saree </p>
    <a href="#" class="btn btn-primary"style={{color:"blue"}}> go somewhere</a>
  </div>
</div>
</div>



<div class="d-flex">
      <div className="card">
  <img src="https://img1.exportersindia.com/product_images/bc-full/2018/9/3410200/indian-sarees-1536214229-4269144.jpg"height="500px" width="500px" alt="..."/>
  <div class="card-body">
    <p class="card-text" style={{Color:"red"}}> Designer saries for women </p>
    <a href="#" class="btn btn-primary"style={{color:"blue"}}> go somewhere</a>
  </div>
</div>

<div className="card">
  <img src="https://assets.shopkund.com/media/catalog/product/cache/3/image/9df78eab33525d08d6e5fb8d27136e95/a/c/act2025-silk-weaving-yellow-south-indian-saree-with-blouse-sr19079.jpg" height="500px" width="500px" alt="..."/>
  <div class="card-body">
    <p class="card-text" style={{Color:"green"}}>Special  saree for girls </p>
    <a href="#" class="btn btn-primary"style={{color:"blue"}}> go somewhere</a>
  </div>
</div>

<div className="card">
  <img src="https://assets2.andaazfashion.com/media/catalog/product/cache/1/image/a12781a7f2ccb3d663f7fd01e1bd2e4e/s/i/silk-indian-saree-in-lime-yellow-colour-sarv03777-1.jpg" height="500px" width="500px" alt="..."/>
  <div class="card-body">
    <p class="card-text" style={{Color:"red"}}> golden  saree for  best in punjabs </p>
    <a href="#" class="btn btn-primary"style={{color:"blue"}}> go somewhere</a>
  </div>
</div>
</div>



<div class="d-flex">
      <div className="card">
  <img src="https://www.mangaldeep.co.in/image/cache/data/fancy-grey-indian-saree-in-silk-32573-800x1100.jpg"height="500px" width="500px" alt="..."/>
  <div class="card-body">
    <p class="card-text" style={{Color:"green"}}> coin saree </p>
    <a href="#" class="btn btn-primary"style={{color:"blue"}}> go somewhere</a>
  </div>
</div>

<div className="card">
  <img src="https://assets.shopkund.com/media/catalog/product/cache/3/image/9df78eab33525d08d6e5fb8d27136e95/a/c/acu7739-1-stone-weaving-brocade-orange-south-indian-saree-with-blouse-sr23335_1_.jpg" height="500px" width="500px" alt="..."/>
  <div class="card-body">
    <p class="card-text" style={{Color:"red"}}>expensive saree </p>
    <a href="#" class="btn btn-primary"style={{color:"blue"}}> go somewhere</a>
  </div>
</div>

<div className="card">
  <img src="https://i.pinimg.com/originals/9d/6c/c4/9d6cc43db3f3bfff8f8181c08242a2e0.jpg" height="500px" width="500px" alt="..."/>
  <div class="card-body">
    <p class="card-text" style={{Color:"blue"}}> gold saree for women </p>
    <a href="#" class="btn btn-primary"style={{color:"blue"}}> go somewhere</a>
  </div>
</div>
</div>



<div class="d-flex">
      <div className="card">
  <img src="https://www.kreeva.com/blog/wp-content/uploads/2022/11/Drape-the-Indian-Saree.jpg"height="500px" width="500px" alt="..."/>
  <div class="card-body">
    <p class="card-text" style={{Color:"red"}}>  foriegn saree </p>
    <a href="#" class="btn btn-primary"style={{color:"blue"}}> go somewhere</a>
  </div>
</div>

<div className="card">
  <img src="https://5.imimg.com/data5/BK/AE/MY-15399851/lovely-red-georgette-with-embroidery-lace-border-work-wedding-wear-indian-saree-for-uk-women-fashion-500x500.jpg" height="500px" width="500px" alt="..."/>
  <div class="card-body">
    <p class="card-text" style={{Color:"yellow"}}>canada saree </p>
    <a href="#" class="btn btn-primary"style={{color:"blue"}}> go somewhere</a>
  </div>
</div>

<div className="card">
  <img src="https://www.m.modnaya-odejda.com/wp-content/uploads/2018/big-photo/i/1830/indian-saree-photo--big-0JS-7VKPDOA.jpg" height="500px" width="500px" alt="..."/>
  <div class="card-body">
    <p class="card-text" style={{Color:"blue"}}> landon </p>
    <a href="#" class="btn btn-primary"style={{color:"blue"}}> go somewhere</a>
  </div>
</div>
</div>



<div class="d-flex">
      <div className="card">
  <img src="https://cdn.pixabay.com/photo/2020/12/13/20/27/woman-5829242_1280.jpg"height="500px" width="500px" alt="..."/>
  <div class="card-body">
    <p class="card-text" style={{Color:"blue"}}> usa saree </p>
    <a href="#" class="btn btn-primary"style={{color:"blue"}}> go somewhere</a>
  </div>
</div>

<div className="card">
  <img src="https://www.m.modnaya-odejda.com/wp-content/uploads/2018/big-photo/i/1830/indian-saree-photo--big-0JS-9KKOFNC.jpg" height="500px" width="500px" alt="..."/>
  <div class="card-body">
    <p class="card-text" style={{Color:"blue"}}>  bangldesh saree </p>
    <a href="#" class="btn btn-primary"style={{color:"blue"}}> go somewhere</a>
  </div>
</div>

<div className="card">
  <img src="https://assets2.andaazfashion.com/media/catalog/product/cache/1/image/a12781a7f2ccb3d663f7fd01e1bd2e4e/s/i/silk-indian-saree-in-lime-yellow-colour-sarv03777-2.jpg" height="500px" width="500px" alt="..."/>
  <div class="card-body">
    <p class="card-text" style={{Color:"blue"}}> brazil saree </p>
    <a href="#" class="btn btn-primary"style={{color:"blue"}}> go somewhere</a>
  </div>
</div>
</div>



<div class="d-flex">
      <div className="card">
  <img src="https://www.shahifits.in/wp-content/uploads/2022/11/South-Indian-Saree-Look-in-Yellow-and-Green-scaled.jpg"height="500px" width="500px" alt="..."/>
  <div class="card-body">
    <p class="card-text" style={{Color:"blue"}}> brampton saree </p>
    <a href="#" class="btn btn-primary"style={{color:"blue"}}> go somewhere</a>
  </div>
</div>

<div className="card">
  <img src="https://i.etsystatic.com/27466298/r/il/fd0fa9/2825658036/il_1080xN.2825658036_3jlp.jpg" height="500px" width="500px" alt="..."/>
  <div class="card-body">
    <p class="card-text" style={{Color:"blue"}}>  shoe piece  for saree </p>
    <a href="#" class="btn btn-primary"style={{color:"blue"}}> go somewhere</a>
  </div>
</div>

<div className="card">
  <img src="https://i.pinimg.com/736x/06/dd/c1/06ddc1bde81f466a3611e61a3968df62.jpg" height="500px" width="500px" alt="..."/>
  <div class="card-body">
    <p class="card-text" style={{Color:"blue"}}>  pure gold saree </p>
    <a href="#" class="btn btn-primary"style={{color:"blue"}}> go somewhere</a>
  </div>
</div>
</div>


<div class="d-flex">
      <div className="card">
  <img src="https://images.pexels.com/photos/12707148/pexels-photo-12707148.jpeg?cs=srgb&dl=pexels-azraq-al-rezoan-12707148.jpg&fm=jpg"height="500px" width="500px" alt="..."/>
  <div class="card-body">
    <p class="card-text" style={{Color:"blue"}}> more saree </p>
    <a href="#" class="btn btn-primary"style={{color:"blue"}}> go somewhere</a>
  </div>
</div>

<div className="card">
  <img src="https://cdn.shopify.com/s/files/1/0252/9897/files/engagement-wear-designer-beige-silk-embroidered-saree.jpg?v=1683369176" height="500px" width="500px" alt="..."/>
  <div class="card-body">
    <p class="card-text" style={{Color:"blue"}}> best piece saree </p>
    <a href="#" class="btn btn-primary"style={{color:"blue"}}> go somewhere</a>
  </div>
</div>

<div className="card">
  <img src="https://g3fashion.com/blog/wp-content/uploads/2022/07/THUMB.jpg" height="500px" width="500px" alt="..."/>
  <div class="card-body">
    <p class="card-text" style={{Color:"blue"}}>  pure cotton saree </p>
    <a href="#" class="btn btn-primary"style={{color:"blue"}}> go somewhere</a>
  </div>
</div>
</div>


<div class="d-flex">
      <div className="card">
  <img src="https://cdn.shopify.com/s/files/1/0162/2116/articles/Traditional_Indian_Saree_Collection_to_Get_Festival_Look_1200x1200.jpg?v=1632213402"height="500px" width="500px" alt="..."/>
  <div class="card-body">
    <p class="card-text" style={{Color:"blue"}}>  pure Designer saree </p>
    <a href="#" class="btn btn-primary"style={{color:"blue"}}> go somewhere</a>
  </div>
</div>

<div className="card">
  <img src="https://grabandpack.com/media/catalog/product/cache/1/image/1330x/9df78eab33525d08d6e5fb8d27136e95/r/e/red-kanchipuram-soft-silk-saree-gnp0109280.jpg" height="500px" width="500px" alt="..."/>
  <div class="card-body">
    <p class="card-text" style={{Color:"blue"}}> non techable saree </p>
    <a href="#" class="btn btn-primary"style={{color:"blue"}}> go somewhere</a>
  </div>
</div>

<div className="card">
  <img src="https://stylesatlife.com/wp-content/uploads/2018/03/Alluring-Red-North-Indian-Saree.jpg.webp" height="500px" width="500px" alt="..."/>
  <div class="card-body">
    <p class="card-text" style={{Color:"blue"}}>  luxery piece of saree  </p>
    <a href="#" class="btn btn-primary"style={{color:"blue"}}> go somewhere</a>
  
  </div>
</div>
</div>



<div class="d-flex">
      <div className="card">
  <img src="https://stylecaret.com/blog/wp-content/uploads/2020/12/4-Simple-Ways-To-Enhance-Your-Look-In-South-Indian-Saree.jpeg"height="500px" width="500px" alt="..."/>
  <div class="card-body">
    <p class="card-text" style={{Color:"blue"}}> look presentive saree </p>
    <a href="#" class="btn btn-primary"style={{color:"blue"}}> go somewhere</a>
  </div>
</div>

<div className="card">
  <img src="https://thumbs.dreamstime.com/b/beautiful-ethnic-indian-saree-young-woman-red-colorful-sensual-wedding-very-feminine-outfit-indian-sari-poses-old-206589571.jpg" height="500px" width="500px" alt="..."/>
  <div class="card-body">
    <p class="card-text" style={{Color:"blue"}}>  good  and expensive saree </p>
    <a href="#" class="btn btn-primary"style={{color:"blue"}}> go somewhere</a>
  </div>
</div>

<div className="card">
  <img src="https://www.bookeventz.com/blog/wp-content/uploads/2021/06/Untitled-design-2021-06-18T161748.695.png" height="500px" width="500px" alt="..."/>
  <div class="card-body">
    <p class="card-text" style={{Color:"blue"}}> silk saree </p>
    <a href="#" class="btn btn-primary"style={{color:"blue"}}> go somewhere</a>
  </div>
</div>
</div>
<div class="d-flex">
      <div className="card">
  <img src="https://images.meesho.com/images/products/144078408/sq8k7_512.webp"height="500px" width="500px" alt="..."/>
  <div class="card-body">
    <p class="card-text" style={{Color:"blue"}}>   siya ram saree </p>
    <a href="#" class="btn btn-primary"style={{color:"blue"}}> go somewhere</a>
  </div>
</div>

<div className="card">
  <img src="https://cityspideynews.s3.amazonaws.com/uploads/spidey/202211/saree-1669033557.webp" height="500px" width="500px" alt="..."/>
  <div class="card-body">
    <p class="card-text" style={{Color:"blue"}}>Diamond saree </p>
    <a href="#" class="btn btn-primary"style={{color:"blue"}}> go somewhere</a>
  </div>
</div>

<div className="card">
  <img src="https://www.google.com/url?sa=i&url=https%3A%2F%2Fwww.pinterest.com%2Fpin%2F414190496950854315%2F&psig=AOvVaw2Awn3iP9PSQBXpNh4dztKs&ust=1685677511830000&source=images&cd=vfe&ved=0CBEQjRxqGAoTCJDqlZyUof8CFQAAAAAdAAAAABC5Ag" height="500px" width="500px" alt="..."/>
  <div class="card-body">
    <p class="card-text" style={{Color:"blue"}}> golden saree </p>
    <a href="#" class="btn btn-primary"style={{color:"blue"}}> go somewhere</a>
  </div>
</div>
</div>



<div class="d-flex">
      <div className="card">
  <img src="https://pbs.twimg.com/profile_images/1106385215/45_400x400.jpg"height="500px" width="500px" alt="..."/>
  <div class="card-body">
    <p class="card-text" style={{Color:"blue"}}> Designer saree </p>
    <a href="#" class="btn btn-primary"style={{color:"blue"}}> go somewhere</a>
  </div>
</div>

<div className="card">
  <img src="https://images.unsplash.com/photo-1617627143750-d86bc21e42bb?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8MXx8aW5kaWFuJTIwc2FyZWV8ZW58MHx8MHx8fDA%3D&w=1000&q=80" height="500px" width="500px" alt="..."/>
  <div class="card-body">
    <p class="card-text" style={{Color:"blue"}}>Diamond saree </p>
    <a href="#" class="btn btn-primary"style={{color:"blue"}}> go somewhere</a>
  </div>
</div>

<div className="card">
  <img src="https://m.media-amazon.com/images/I/61nWyafHxJL._UY550_.jpg" height="500px" width="500px" alt="..."/>
  <div class="card-body">
    <p class="card-text" style={{Color:"blue"}}> golden saree </p>
    <a href="#" class="btn btn-primary"style={{color:"blue"}}> go somewhere</a>
  </div>
</div>
</div>




<div class="d-flex">
      <div className="card">
  <img src="https://assets.shopkund.com/media/catalog/product/cache/3/image/9df78eab33525d08d6e5fb8d27136e95/a/c/act7111-1-raw-silk-weaving-green-south-indian-saree-with-blouse-sr20547.jpg"height="500px" width="500px" alt="..."/>
  <div class="card-body">
    <p class="card-text" style={{Color:"blue"}}> Designer saree </p>
    <a href="#" class="btn btn-primary"style={{color:"blue"}}> go somewhere</a>
  </div>
</div>

<div className="card">
  <img src="https://cdn.shopify.com/s/files/1/0592/3117/4816/articles/Types_of_Sarees_in_India_grande.jpg?v=1664648179" height="500px" width="500px" alt="..."/>
  <div class="card-body">
    <p class="card-text" style={{Color:"blue"}}>Diamond saree </p>
    <a href="#" class="btn btn-primary"style={{color:"blue"}}> go somewhere</a>
  </div>
</div>

<div className="card">
  <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTjskve4UAuUry-KXA0XZmPU113RccFaSdg68IW9DqRTw&usqp=CAU&ec=48665699" height="500px" width="500px" alt="..."/>
  <div class="card-body">
    <p class="card-text" style={{Color:"blue"}}> golden saree </p>
    <a href="#" class="btn btn-primary"style={{color:"blue"}}> go somewhere</a>
  </div>
</div>
</div>


<div class="d-flex">
      <div className="card">
  <img src="https://stylesatlife.com/wp-content/uploads/2019/10/North-Indian-Sarees-Try-These-15-Eye-Catching-Designs.jpg"height="500px" width="500px" alt="..."/>
  <div class="card-body">
    <p class="card-text" style={{Color:"blue"}}> Designer saree </p>
    <a href="#" class="btn btn-primary"style={{color:"blue"}}> go somewhere</a>
  </div>
</div>

<div className="card">
  <img src="https://grabandpack.com/media/catalog/product/cache/1/image/1280x/9df78eab33525d08d6e5fb8d27136e95/y/e/yellow-coloured-soft-silk-indian-designer-saree-gnp0108145.jpeg" height="500px" width="500px" alt="..."/>
  <div class="card-body">
    <p class="card-text" style={{Color:"blue"}}>Diamond saree </p>
    <a href="#" class="btn btn-primary"style={{color:"blue"}}> go somewhere</a>
  </div>
</div>

<div className="card">
  <img src="https://www.shahifits.in/wp-content/uploads/2022/11/South-Indian-Wedding-Saree-Sky-Blue-Colour-scaled.jpg" height="500px" width="500px" alt="..."/>
  <div class="card-body">
    <p class="card-text" style={{Color:"blue"}}> golden saree </p>
    <a href="#" class="btn btn-primary"style={{color:"blue"}}> go somewhere</a>
  </div>
</div>
</div>


<div class="d-flex">
      <div className="card">
  <img src="https://www.jiofab.com/media/catalog/product/cache/1e8ef93b9b4867ab9f3538dde2cb3b8a/f/a/fanta-art-silk-indian-saree-jf23528.jpg"height="500px" width="500px" alt="..."/>
  <div class="card-body">
    <p class="card-text" style={{Color:"blue"}}> Designer saree </p>
    <a href="#" class="btn btn-primary"style={{color:"blue"}}> go somewhere</a>
  </div>
</div>

<div className="card">
  <img src="https://tri3d.in/wp-content/uploads/2020/04/Saree-9-1400x788.png" height="500px" width="500px" alt="..."/>
  <div class="card-body">
    <p class="card-text" style={{Color:"blue"}}>Diamond saree </p>
    <a href="#" class="btn btn-primary"style={{color:"blue"}}> go somewhere</a>
  </div>
</div>

<div className="card">
  <img src="https://cdn.shopify.com/s/files/1/0592/5725/8171/products/0O8A8249_600x.jpg?v=1681369392" height="500px" width="500px" alt="..."/>
  <div class="card-body">
    <p class="card-text" style={{Color:"blue"}}> golden saree </p>
    <a href="#" class="btn btn-primary"style={{color:"blue"}}> go somewhere</a>
  </div>
</div>
</div>


<div class="d-flex">
      <div className="card">
  <img src="https://www.desiblitz.com/wp-content/uploads/2020/12/The-Indian-Saree-A-Garment-with-a-Story-identity.jpg"height="500px" width="500px" alt="..."/>
  <div class="card-body">
    <p class="card-text" style={{Color:"blue"}}> Designer saree </p>
    <a href="#" class="btn btn-primary"style={{color:"blue"}}> go somewhere</a>
  </div>
</div>

<div className="card">
  <img src="https://g3fashion.com/blog/wp-content/uploads/2021/08/south-indian-saree-for-bride-1-e1628512583130.jpg" height="500px" width="500px" alt="..."/>
  <div class="card-body">
    <p class="card-text" style={{Color:"blue"}}>Diamond saree </p>
    <a href="#" class="btn btn-primary"style={{color:"blue"}}> go somewhere</a>
  </div>
</div>

<div className="card">
  <img src="https://cdn.shopify.com/s/files/1/0182/1471/5470/articles/What-are-the-Best-Indian-Saree-Designs-for-2022-Diwali-Festival.jpg?v=1670403364" height="500px" width="500px" alt="..."/>
  <div class="card-body">
    <p class="card-text" style={{Color:"blue"}}> golden saree </p>
    <a href="#" class="btn btn-primary"style={{color:"blue"}}> go somewhere</a>
  </div>
</div>
</div>

<h1 style={{Color:"blue"}}>talk about jewelery</h1>
<p style={{Color:"red"}}>Objects designed for the adornment of the body are called jewelry. While modern jewelry is made of gold, silver, or platinum, often with precious or semiprecious stones, it evolved from shells, animal teeth, and other items used as body decoration in prehistoric times. Over the centuries it came to be a sign of social or religious rank, and in Renaissance Italy, jewelry-making reached the status of a fine art. By the 19th century, industrialization brought jewelry within the reach of the middle class. Firms opened by such jewelers as Carl Fabergé and Louis Comfort Tiffany achieved great success by making fine jewelry for the wealthy.</p>

<h2>Materials and methods</h2>
<p> In creating jewellery, gemstones, coins, or other precious items are often used, and they are typically set into precious metals. Platinum alloys range from 900 (90% pure) to 950 (95% pure). The silver used in jewellery is usually sterling silver, or 92.5% fine silver. In costume jewellery, stainless steel findings are sometimes used.

Other commonly used materials include glass, such as fused-glass or enamel; wood, often carved or turned; shells and other natural animal substances such as bone and ivory; natural clay; polymer clay; Hemp and other twines have been used as well to create jewellery that has more of a natural feel. However, any inclusion of lead or lead solder will give a British Assay office (the body which gives U.K. jewellery its stamp of approval, the Hallmark) the right to destroy the piece, however it is very rare for the assay office to do so.

Beads are frequently used in jewellery. These may be made of glass, gemstones, metal, wood, shells, clay and polymer clay. Beaded jewellery commonly encompasses necklaces, bracelets, earrings, belts and rings. Beads may be large or small; the smallest type of beads used are known as seed beads, these are the beads used for the "woven" style of beaded jewellery. Seed beads are also used in an embroidery technique where they are sewn onto fabric backings to create broad collar neck pieces and beaded bracelets. Bead embroidery, a popular type of handwork during the Victorian era, is enjoying a renaissance in modern jewellery making. Beading, or beadwork, is also very popular in many African and indigenous North American cultures.

Silversmiths, goldsmiths, and lapidaries use methods including forging, casting, soldering or welding, cutting, carving and "cold-joining" (using adhesives, staples and rivets to assemble parts)</p>

<div style={{backgroundColor:"grey"}} className="text-center"/>
        <center><h1 style ={{color:"red"}}>My Contact Detail</h1></center><hr/>
        <div style={{display:"flex"}} className="container"/>
            <div className="col-lg-6 text-center">
                <h1 style ={{color:"blue"}}>Shop website</h1>
                <h1 style ={{color:"red"}}>Mail to:sanjammahajan333@gmail.com</h1>
                <h1 style ={{color:"green"}}>9779880636</h1>
                <img src="https://cdn-icons-png.flaticon.com/128/4782/4782351.png"height="50px"/>
                <img src="https://cdn-icons-png.flaticon.com/128/5968/5968534.png"height="50px"/>
                <img src="https://cdn-icons-png.flaticon.com/128/145/145802.png"height="50px"/> 
                <img src="https://cdn-icons-png.flaticon.com/128/2111/2111463.png"height="50px"/>
    </div>
    </div>
  )
}

export default About
