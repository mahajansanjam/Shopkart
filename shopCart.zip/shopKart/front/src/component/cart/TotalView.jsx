



const Totalview = () => {
    return (
        <div>hello</div>
    )
}

export default Totalview;