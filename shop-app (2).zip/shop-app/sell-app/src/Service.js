
import React from 'react'

function Service() {
  return (
    <div>
        <div class="d-flex">
      <div className="card" >
  <img src=" https://images.pexels.com/photos/1767434/pexels-photo-1767434.jpeg?auto=compress&cs=tinysrgb&dpr=1&w=500"class="card-img-top" height="500px" width="500px" alt="..."/>
  <div class="card-body">
    <p class="card-text" style={{backgroundColor:"blue"}}>Children toys section</p>
    <a href="#" class="btn btn-primary"style={{color:"blue"}}> go somewhere</a>
  </div>
</div>


<div className="card" >
  <img src="https://c0.wallpaperflare.com/preview/265/849/245/toys.jpg" class="card-img-top" height="500px" width="500px" alt="..."/>
  <div class="card-body">
    <p class="card-text">best toy section</p>
    <a href="#" class="btn btn-primary"style={{color:"blue"}}> go somewhere</a>
  </div>
</div>


<div className="card" >
  <img src="https://images.pexels.com/photos/207891/pexels-photo-207891.jpeg?cs=srgb&dl=pexels-pixabay-207891.jpg&fm=jpg" class="card-img-top" height="500px" width="500px" alt="..."/>
  <div class="card-body">
    <p class="card-text"> Toys Section</p>
    <a href="#" class="btn btn-primary"style={{color:"blue"}}> go somewhere</a>
  </div>
</div>
</div>


<div class="d-flex">
      <div className="card" >
  <img src=" https://i.pinimg.com/736x/a5/ec/4d/a5ec4dc697dd5d627115c3fefed11dd1.jpg"class="card-img-top" height="500px" width="500px" alt="..."/>
  <div class="card-body">
    <p class="card-text">Children fun  section</p>
    <a href="#" class="btn btn-primary"style={{color:"blue"}}> go somewhere</a>
  </div>
</div>


<div className="card" >
  <img src="https://cdn.wallpapersafari.com/2/7/7LMVWj.jpg" class="card-img-top" height="500px" width="500px" alt="..."/>
  <div class="card-body">
    <p class="card-text">Story section</p>
    <a href="#" class="btn btn-primary"style={{color:"blue"}}> go somewhere</a>
  </div>
</div>


<div className="card" >
  <img src="https://images8.alphacoders.com/446/446310.jpg" class="card-img-top" height="500px" width="500px" alt="..."/>
  <div class="card-body">
    <p class="card-text"> Toys story section </p>
    <a href="#" class="btn btn-primary"style={{color:"blue"}}> go somewhere</a>
  </div>
</div>
</div>


<form class="d-flex" role="search">
        <input class="form-control me-2" type="search" placeholder="Search" aria-label="Search"/>
        <button  style ={{color: "variant"}}class="btn btn-outline-success" type="submit">Search</button>
      </form>




<div id="carouselExample" class="carousel slide">
  <div class="carousel-inner">
    <div class="carousel-item active">
      <img src="https://wallpaperaccess.com/full/3603755.jpg" class="d-block w-100" height ="500px" width="500px" alt="..."/>
    </div>
    <div class="carousel-item">
      <img src="https://images.pexels.com/photos/1716861/pexels-photo-1716861.jpeg?cs=srgb&dl=pexels-carolina-castilla-arias-1716861.jpg&fm=jpg" class="d-block w-100" height="500px" width="500px" alt="..."/>
    </div>
    <div class="carousel-item">
      <img src="https://wallpaper.dog/large/5528687.jpg" class="d-block w-100" height="500px" width="500px" alt="..."/>
    </div>
  </div>
  <button class="carousel-control-prev" type="button" data-bs-target="#carouselExample" data-bs-slide="prev">
    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
    <span class="visually-hidden">Previous</span>
  </button>
  <button class="carousel-control-next" type="button" data-bs-target="#carouselExample" data-bs-slide="next">
    <span class="carousel-control-next-icon" aria-hidden="true"></span>
    <span class="visually-hidden">Next</span>
  </button>
</div>


<div class="d-flex">
      <div className="card" >
  <img src=" https://wallpaperaccess.com/full/1804570.jpg"class="card-img-top" height="500px" width="500px" alt="..."/>
  <div class="card-body">
    <p class="card-text">Best children toys section</p>
    <a href="#" class="btn btn-primary"style={{color:"blue"}}> go somewhere</a>
  </div>
</div>


<div className="card" >
  <img src="https://wallpaperaccess.com/full/3603717.jpg" class="card-img-top" height="500px" width="500px" alt="..."/>
  <div class="card-body">
    <p class="card-text">boys toys section</p>
    <a href="#" class="btn btn-primary"style={{color:"blue"}}> go somewhere</a>
  </div>
</div>


<div className="card" >
  <img src="https://wallpaper.dog/large/5528690.jpg`" class="card-img-top" height="500px" width="500px" alt="..."/>
  <div class="card-body">
    <p class="card-text"> Top toys collection</p>
    <a href="#" class="btn btn-primary"style={{color:"blue"}}> go somewhere</a>
  </div>
</div>
</div>


<div class="d-flex">
      <div className="card" >
  <img src="https://c1.wallpaperflare.com/preview/128/907/830/mickey-mouse-disney-mickey-minnie.jpg "class="card-img-top" height="500px" width="500px" alt="..."/>
  <div class="card-body">
    <p class="card-text">Iron man collections</p>
    <a href="#" class="btn btn-primary"style={{color:"blue"}}> go somewhere</a>
  </div>
</div>


<div className="card" >
  <img src="https://rare-gallery.com/thumbs/1254368-i-love-you-teddy-bear.jpg" class="card-img-top" height="500px" width="500px" alt="..."/>
  <div class="card-body">
    <p class="card-text">Spiderman section</p>
    <a href="#" class="btn btn-primary"style={{color:"blue"}}> go somewhere</a>
  </div>
</div>


<div className="card" >
  <img src="https://i.pinimg.com/originals/2d/9d/11/2d9d117550917607e4abc8fe2fba7e2e.jpg" class="card-img-top" height="500px" width="500px" alt="..."/>
  <div class="card-body">
    <p class="card-text"> doremon section </p>
    <a href="#" class="btn btn-primary"style={{color:"blue"}}> go somewhere</a>
  </div>
</div>
</div>


<div class="d-flex">
      <div className="card" >
  <img src=" https://cdn.vox-cdn.com/thumbor/f2bPL4CEtdsSLrGDxd4HKKKO6Gs=/0x0:1920x1080/1200x800/filters:focal(1035x326:1341x632)/cdn.vox-cdn.com/uploads/chorus_image/image/71812214/Ash_Ketchum_World_Champion_Screenshot_4.0.jpg"class="card-img-top" height="500px" width="500px" alt="..."/>
  <div class="card-body">
    <p class="card-text">pokemon collection</p>
    <a href="#" class="btn btn-primary"style={{color:"blue"}}> go somewhere</a>
  </div>
</div>


<div className="card" >
  <img src="https://ludoking.com/images/left.png" class="card-img-top" height="500px" width="500px" alt="..."/>
  <div class="card-body">
    <p class="card-text">luddo section</p>
    <a href="#" class="btn btn-primary"style={{color:"blue"}}> go somewhere</a>
  </div>
</div>


<div className="card" >
  <img src="https://upload.wikimedia.org/wikipedia/commons/thumb/7/71/Sector-coupling-800x566.jpg/1024px-Sector-coupling-800x566.jpg" class="card-img-top" height="500px" width="500px" alt="..."/>
  <div class="card-body">
    <p class="card-text"> spower section </p>
    <a href="#" class="btn btn-primary"style={{color:"blue"}}> go somewhere</a>
  </div>
</div>
</div>



<div class="d-flex">
      <div className="card" >
  <img src=" https://play-lh.googleusercontent.com/MDaSgXlbRkftfjNIdJ2oHodVBVLOmVg2PevfdzJkbtlawfMA-8gMAs-kCfXXY5XyLw"class="card-img-top" height="500px" width="500px" alt="..."/>
  <div class="card-body">
    <p class="card-text">pokemon  lovers</p>
    <a href="#" class="btn btn-primary"style={{color:"blue"}}> go somewhere</a>
  </div>
</div>


<div className="card" >
  <img src="https://englishtribuneimages.blob.core.windows.net/gallary-content/2023/4/2023_4$largeimg_1809198464.jpeg" class="card-img-top" height="500px" width="500px" alt="..."/>
  <div class="card-body">
    <p class="card-text">luddo  lovers</p>
    <a href="#" class="btn btn-primary"style={{color:"blue"}}> go somewhere</a>
  </div>
</div>


<div className="card" >
  <img src="https://5.imimg.com/data5/JA/UO/AA/SELLER-359783/caram-board-1-500x500.jpg" class="card-img-top" height="500px" width="500px" alt="..."/>
  <div class="card-body">
    <p class="card-text"> caramboard </p>
    <a href="#" class="btn btn-primary"style={{color:"blue"}}> go somewhere</a>
  </div>
</div>
</div>




<div class="d-flex">
      <div className="card" >
  <img src=" https://i.ytimg.com/vi/15ywT985KQU/maxresdefault.jpg"class="card-img-top" height="500px" width="500px" alt="..."/>
  <div class="card-body">
    <p class="card-text"> chotabeam</p>
    <a href="#" class="btn btn-primary"style={{color:"blue"}}> go somewhere</a>
  </div>
</div>


<div className="card" >
  <img src="https://m.media-amazon.com/images/I/41-MPIeERWL._AC_UF1000,1000_QL80_.jpg" class="card-img-top" height="500px" width="500px" alt="..."/>
  <div class="card-body">
    <p class="card-text"> teddy bear</p>
    <a href="#" class="btn btn-primary"style={{color:"blue"}}> go somewhere</a>
  </div>
</div>


<div className="card" >
  <img src="https://images.hindustantimes.com/auto/img/2023/05/10/1600x900/porsche-718-spyder-rs_1683688570901_1683688576929.jpg" class="card-img-top" height="500px" width="500px" alt="..."/>
  <div class="card-body">
    <p class="card-text">  spyder section </p>
    <a href="#" class="btn btn-primary"style={{color:"blue"}}> go somewhere</a>
  </div>
</div>
</div>




<div class="d-flex">
      <div className="card" >
  <img src=" https://cdn.vox-cdn.com/thumbor/f2bPL4CEtdsSLrGDxd4HKKKO6Gs=/0x0:1920x1080/1200x800/filters:focal(1035x326:1341x632)/cdn.vox-cdn.com/uploads/chorus_image/image/71812214/Ash_Ketchum_World_Champion_Screenshot_4.0.jpg"class="card-img-top" height="500px" width="500px" alt="..."/>
  <div class="card-body">
    <p class="card-text">pokemon collection in punjab</p>
    <a href="#" class="btn btn-primary"style={{color:"blue"}}> go somewhere</a>
  </div>
</div>


<div className="card" >
  <img src="https://ludoking.com/images/left.png" class="card-img-top" height="500px" width="500px" alt="..."/>
  <div class="card-body">
    <p class="card-text">luddo section</p>
    <a href="#" class="btn btn-primary"style={{color:"blue"}}> go somewhere</a>
  </div>
</div>


<div className="card" >
  <img src="https://upload.wikimedia.org/wikipedia/commons/thumb/7/71/Sector-coupling-800x566.jpg/1024px-Sector-coupling-800x566.jpg" class="card-img-top" height="500px" width="500px" alt="..."/>
  <div class="card-body">
    <p class="card-text"> spower section </p>
    <a href="#" class="btn btn-primary"style={{color:"blue"}}> go somewhere</a>
  </div>
</div>
</div>



<div class="d-flex">
      <div className="card" >
  <img src=" https://cdn.vox-cdn.com/thumbor/f2bPL4CEtdsSLrGDxd4HKKKO6Gs=/0x0:1920x1080/1200x800/filters:focal(1035x326:1341x632)/cdn.vox-cdn.com/uploads/chorus_image/image/71812214/Ash_Ketchum_World_Champion_Screenshot_4.0.jpg"class="card-img-top" height="500px" width="500px" alt="..."/>
  <div class="card-body">
    <p class="card-text">pokemon collection</p>
    <a href="#" class="btn btn-primary"style={{color:"blue"}}> go somewhere</a>
  </div>
</div>


<div className="card" >
  <img src="https://ludoking.com/images/left.png" class="card-img-top" height="500px" width="500px" alt="..."/>
  <div class="card-body">
    <p class="card-text">luddo section</p>
    <a href="#" class="btn btn-primary"style={{color:"blue"}}> go somewhere</a>
  </div>
</div>


<div className="card" >
  <img src="https://upload.wikimedia.org/wikipedia/commons/thumb/7/71/Sector-coupling-800x566.jpg/1024px-Sector-coupling-800x566.jpg" class="card-img-top" height="500px" width="500px" alt="..."/>
  <div class="card-body">
    <p class="card-text"> spower section </p>
    <a href="#" class="btn btn-primary"style={{color:"blue"}}> go somewhere</a>
  </div>
</div>
</div>



<div class="d-flex">
      <div className="card" >
  <img src=" https://cdn.vox-cdn.com/thumbor/f2bPL4CEtdsSLrGDxd4HKKKO6Gs=/0x0:1920x1080/1200x800/filters:focal(1035x326:1341x632)/cdn.vox-cdn.com/uploads/chorus_image/image/71812214/Ash_Ketchum_World_Champion_Screenshot_4.0.jpg"class="card-img-top" height="500px" width="500px" alt="..."/>
  <div class="card-body">
    <p class="card-text">pokemon collection</p>
    <a href="#" class="btn btn-primary"style={{color:"blue"}}> go somewhere</a>
  </div>
</div>


<div className="card" >
  <img src="https://ludoking.com/images/left.png" class="card-img-top" height="500px" width="500px" alt="..."/>
  <div class="card-body">
    <p class="card-text">luddo section</p>
    <a href="#" class="btn btn-primary"style={{color:"blue"}}> go somewhere</a>
  </div>
</div>


<div className="card" >
  <img src="https://upload.wikimedia.org/wikipedia/commons/thumb/7/71/Sector-coupling-800x566.jpg/1024px-Sector-coupling-800x566.jpg" class="card-img-top" height="500px" width="500px" alt="..."/>
  <div class="card-body">
    <p class="card-text"> spower section </p>
    <a href="#" class="btn btn-primary"style={{color:"blue"}}> go somewhere</a>
  </div>
</div>
</div>


<div class="d-flex">
      <div className="card" >
  <img src=" https://cdn.vox-cdn.com/thumbor/f2bPL4CEtdsSLrGDxd4HKKKO6Gs=/0x0:1920x1080/1200x800/filters:focal(1035x326:1341x632)/cdn.vox-cdn.com/uploads/chorus_image/image/71812214/Ash_Ketchum_World_Champion_Screenshot_4.0.jpg"class="card-img-top" height="500px" width="500px" alt="..."/>
  <div class="card-body">
    <p class="card-text">pokemon collection</p>
    <a href="#" class="btn btn-primary"style={{color:"blue"}}> go somewhere</a>
  </div>
</div>


<div className="card" >
  <img src="https://ludoking.com/images/left.png" class="card-img-top" height="500px" width="500px" alt="..."/>
  <div class="card-body">
    <p class="card-text">luddo section</p>
    <a href="#" class="btn btn-primary"style={{color:"blue"}}> go somewhere</a>
  </div>
</div>


<div className="card" >
  <img src="https://upload.wikimedia.org/wikipedia/commons/thumb/7/71/Sector-coupling-800x566.jpg/1024px-Sector-coupling-800x566.jpg" class="card-img-top" height="500px" width="500px" alt="..."/>
  <div class="card-body">
    <p class="card-text"> spower section </p>
    <a href="#" class="btn btn-primary"style={{color:"blue"}}> go somewhere</a>
  </div>
</div>
</div>



<div class="d-flex">
      <div className="card" >
  <img src=" https://cdn.vox-cdn.com/thumbor/f2bPL4CEtdsSLrGDxd4HKKKO6Gs=/0x0:1920x1080/1200x800/filters:focal(1035x326:1341x632)/cdn.vox-cdn.com/uploads/chorus_image/image/71812214/Ash_Ketchum_World_Champion_Screenshot_4.0.jpg"class="card-img-top" height="500px" width="500px" alt="..."/>
  <div class="card-body">
    <p class="card-text">pokemon collection</p>
    <a href="#" class="btn btn-primary"style={{color:"blue"}}> go somewhere</a>
  </div>
</div>


<div className="card" >
  <img src="https://ludoking.com/images/left.png" class="card-img-top" height="500px" width="500px" alt="..."/>
  <div class="card-body">
    <p class="card-text">luddo section</p>
    <a href="#" class="btn btn-primary"style={{color:"blue"}}> go somewhere</a>
  </div>
</div>


<div className="card" >
  <img src="https://upload.wikimedia.org/wikipedia/commons/thumb/7/71/Sector-coupling-800x566.jpg/1024px-Sector-coupling-800x566.jpg" class="card-img-top" height="500px" width="500px" alt="..."/>
  <div class="card-body">
    <p class="card-text"> spower section </p>
    <a href="#" class="btn btn-primary"style={{color:"blue"}}> go somewhere</a>
  </div>
</div>
</div>


<div class="d-flex">
      <div className="card" >
  <img src=" https://cdn.vox-cdn.com/thumbor/f2bPL4CEtdsSLrGDxd4HKKKO6Gs=/0x0:1920x1080/1200x800/filters:focal(1035x326:1341x632)/cdn.vox-cdn.com/uploads/chorus_image/image/71812214/Ash_Ketchum_World_Champion_Screenshot_4.0.jpg"class="card-img-top" height="500px" width="500px" alt="..."/>
  <div class="card-body">
    <p class="card-text">pokemon collection</p>
    <a href="#" class="btn btn-primary"style={{color:"blue"}}> go somewhere</a>
  </div>
</div>


<div className="card" >
  <img src="https://ludoking.com/images/left.png" class="card-img-top" height="500px" width="500px" alt="..."/>
  <div class="card-body">
    <p class="card-text">luddo section</p>
    <a href="#" class="btn btn-primary"style={{color:"blue"}}> go somewhere</a>
  </div>
</div>


<div className="card" >
  <img src="https://upload.wikimedia.org/wikipedia/commons/thumb/7/71/Sector-coupling-800x566.jpg/1024px-Sector-coupling-800x566.jpg" class="card-img-top" height="500px" width="500px" alt="..."/>
  <div class="card-body">
    <p class="card-text"> spower section </p>
    <a href="#" class="btn btn-primary"style={{color:"blue"}}> go somewhere</a>
  </div>
</div>
</div>



<div class="d-flex">
      <div className="card" >
  <img src=" https://cdn.vox-cdn.com/thumbor/f2bPL4CEtdsSLrGDxd4HKKKO6Gs=/0x0:1920x1080/1200x800/filters:focal(1035x326:1341x632)/cdn.vox-cdn.com/uploads/chorus_image/image/71812214/Ash_Ketchum_World_Champion_Screenshot_4.0.jpg"class="card-img-top" height="500px" width="500px" alt="..."/>
  <div class="card-body">
    <p class="card-text">pokemon collection</p>
    <a href="#" class="btn btn-primary"style={{color:"blue"}}> go somewhere</a>
  </div>
</div>


<div className="card" >
  <img src="https://ludoking.com/images/left.png" class="card-img-top" height="500px" width="500px" alt="..."/>
  <div class="card-body">
    <p class="card-text">luddo section</p>
    <a href="#" class="btn btn-primary"style={{color:"blue"}}> go somewhere</a>
  </div>
</div>


<div className="card" >
  <img src="https://upload.wikimedia.org/wikipedia/commons/thumb/7/71/Sector-coupling-800x566.jpg/1024px-Sector-coupling-800x566.jpg" class="card-img-top" height="500px" width="500px" alt="..."/>
  <div class="card-body">
    <p class="card-text"> spower section </p>
    <a href="#" class="btn btn-primary"style={{color:"blue"}}> go somewhere</a>
  </div>
</div>
</div>


<div class="d-flex">
      <div className="card" >
  <img src=" https://cdn.vox-cdn.com/thumbor/f2bPL4CEtdsSLrGDxd4HKKKO6Gs=/0x0:1920x1080/1200x800/filters:focal(1035x326:1341x632)/cdn.vox-cdn.com/uploads/chorus_image/image/71812214/Ash_Ketchum_World_Champion_Screenshot_4.0.jpg"class="card-img-top" height="500px" width="500px" alt="..."/>
  <div class="card-body">
    <p class="card-text">pokemon collection</p>
    <a href="#" class="btn btn-primary"style={{color:"blue"}}> go somewhere</a>
  </div>
</div>


<div className="card" >
  <img src="https://ludoking.com/images/left.png" class="card-img-top" height="500px" width="500px" alt="..."/>
  <div class="card-body">
    <p class="card-text">luddo section</p>
    <a href="#" class="btn btn-primary"style={{color:"blue"}}> go somewhere</a>
  </div>
</div>


<div className="card" >
  <img src="https://upload.wikimedia.org/wikipedia/commons/thumb/7/71/Sector-coupling-800x566.jpg/1024px-Sector-coupling-800x566.jpg" class="card-img-top" height="500px" width="500px" alt="..."/>
  <div class="card-body">
    <p class="card-text"> spower section </p>
    <a href="#" class="btn btn-primary"style={{color:"blue"}}> go somewhere</a>
  </div>
</div>
</div>


<div class="d-flex">
      <div className="card" >
  <img src=" https://cdn.vox-cdn.com/thumbor/f2bPL4CEtdsSLrGDxd4HKKKO6Gs=/0x0:1920x1080/1200x800/filters:focal(1035x326:1341x632)/cdn.vox-cdn.com/uploads/chorus_image/image/71812214/Ash_Ketchum_World_Champion_Screenshot_4.0.jpg"class="card-img-top" height="500px" width="500px" alt="..."/>
  <div class="card-body">
    <p class="card-text">pokemon collection</p>
    <a href="#" class="btn btn-primary"style={{color:"blue"}}> go somewhere</a>
  </div>
</div>


<div className="card" >
  <img src="https://ludoking.com/images/left.png" class="card-img-top" height="500px" width="500px" alt="..."/>
  <div class="card-body">
    <p class="card-text">luddo section</p>
    <a href="#" class="btn btn-primary"style={{color:"blue"}}> go somewhere</a>
  </div>
</div>


<div className="card" >
  <img src="https://upload.wikimedia.org/wikipedia/commons/thumb/7/71/Sector-coupling-800x566.jpg/1024px-Sector-coupling-800x566.jpg" class="card-img-top" height="500px" width="500px" alt="..."/>
  <div class="card-body">
    <p class="card-text"> spower section </p>
    <a href="#" class="btn btn-primary"style={{color:"blue"}}> go somewhere</a>
  </div>
</div>
</div>



<div class="d-flex">
      <div className="card" >
  <img src=" https://cdn.vox-cdn.com/thumbor/f2bPL4CEtdsSLrGDxd4HKKKO6Gs=/0x0:1920x1080/1200x800/filters:focal(1035x326:1341x632)/cdn.vox-cdn.com/uploads/chorus_image/image/71812214/Ash_Ketchum_World_Champion_Screenshot_4.0.jpg"class="card-img-top" height="500px" width="500px" alt="..."/>
  <div class="card-body">
    <p class="card-text">pokemon collection</p>
    <a href="#" class="btn btn-primary"style={{color:"blue"}}> go somewhere</a>
  </div>
</div>


<div className="card" >
  <img src="https://ludoking.com/images/left.png" class="card-img-top" height="500px" width="500px" alt="..."/>
  <div class="card-body">
    <p class="card-text">luddo section</p>
    <a href="#" class="btn btn-primary"style={{color:"blue"}}> go somewhere</a>
  </div>
</div>


<div className="card" >
  <img src="https://upload.wikimedia.org/wikipedia/commons/thumb/7/71/Sector-coupling-800x566.jpg/1024px-Sector-coupling-800x566.jpg" class="card-img-top" height="500px" width="500px" alt="..."/>
  <div class="card-body">
    <p class="card-text"> spower section </p>
    <a href="#" class="btn btn-primary"style={{color:"blue"}}> go somewhere</a>
  </div>
</div>
</div>



<div class="d-flex">
      <div className="card" >
  <img src=" https://cdn.vox-cdn.com/thumbor/f2bPL4CEtdsSLrGDxd4HKKKO6Gs=/0x0:1920x1080/1200x800/filters:focal(1035x326:1341x632)/cdn.vox-cdn.com/uploads/chorus_image/image/71812214/Ash_Ketchum_World_Champion_Screenshot_4.0.jpg"class="card-img-top" height="500px" width="500px" alt="..."/>
  <div class="card-body">
    <p class="card-text">pokemon collection</p>
    <a href="#" class="btn btn-primary"style={{color:"blue"}}> go somewhere</a>
  </div>
</div>


<div className="card" >
  <img src="https://ludoking.com/images/left.png" class="card-img-top" height="500px" width="500px" alt="..."/>
  <div class="card-body">
    <p class="card-text">luddo section</p>
    <a href="#" class="btn btn-primary"style={{color:"blue"}}> go somewhere</a>
  </div>
</div>


<div className="card" >
  <img src="https://upload.wikimedia.org/wikipedia/commons/thumb/7/71/Sector-coupling-800x566.jpg/1024px-Sector-coupling-800x566.jpg" class="card-img-top" height="500px" width="500px" alt="..."/>
  <div class="card-body">
    <p class="card-text"> spower section </p>
    <a href="#" class="btn btn-primary"style={{color:"blue"}}> go somewhere</a>
  </div>
</div>
</div>


<div class="d-flex">
      <div className="card" >
  <img src=" https://cdn.vox-cdn.com/thumbor/f2bPL4CEtdsSLrGDxd4HKKKO6Gs=/0x0:1920x1080/1200x800/filters:focal(1035x326:1341x632)/cdn.vox-cdn.com/uploads/chorus_image/image/71812214/Ash_Ketchum_World_Champion_Screenshot_4.0.jpg"class="card-img-top" height="500px" width="500px" alt="..."/>
  <div class="card-body">
    <p class="card-text">pokemon collection</p>
    <a href="#" class="btn btn-primary"style={{color:"blue"}}> go somewhere</a>
  </div>
</div>


<div className="card" >
  <img src="https://ludoking.com/images/left.png" class="card-img-top" height="500px" width="500px" alt="..."/>
  <div class="card-body">
    <p class="card-text">luddo section</p>
    <a href="#" class="btn btn-primary"style={{color:"blue"}}> go somewhere</a>
  </div>
</div>


<div className="card" >
  <img src="https://upload.wikimedia.org/wikipedia/commons/thumb/7/71/Sector-coupling-800x566.jpg/1024px-Sector-coupling-800x566.jpg" class="card-img-top" height="500px" width="500px" alt="..."/>
  <div class="card-body">
    <p class="card-text"> spower section </p>
    <a href="#" class="btn btn-primary"style={{color:"blue"}}> go somewhere</a>
  </div>
</div>
</div>


<div class="d-flex">
      <div className="card" >
  <img src=" https://cdn.vox-cdn.com/thumbor/f2bPL4CEtdsSLrGDxd4HKKKO6Gs=/0x0:1920x1080/1200x800/filters:focal(1035x326:1341x632)/cdn.vox-cdn.com/uploads/chorus_image/image/71812214/Ash_Ketchum_World_Champion_Screenshot_4.0.jpg"class="card-img-top" height="500px" width="500px" alt="..."/>
  <div class="card-body">
    <p class="card-text">pokemon collection</p>
    <a href="#" class="btn btn-primary"style={{color:"blue"}}> go somewhere</a>
  </div>
</div>


<div className="card" >
  <img src="https://ludoking.com/images/left.png" class="card-img-top" height="500px" width="500px" alt="..."/>
  <div class="card-body">
    <p class="card-text">luddo section</p>
    <a href="#" class="btn btn-primary"style={{color:"blue"}}> go somewhere</a>
  </div>
</div>


<div className="card" >
  <img src="https://upload.wikimedia.org/wikipedia/commons/thumb/7/71/Sector-coupling-800x566.jpg/1024px-Sector-coupling-800x566.jpg" class="card-img-top" height="500px" width="500px" alt="..."/>
  <div class="card-body">
    <p class="card-text"> spower section </p>
    <a href="#" class="btn btn-primary"style={{color:"blue"}}> go somewhere</a>
  </div>
</div>
</div>


<div class="d-flex">
      <div className="card" >
  <img src=" https://cdn.vox-cdn.com/thumbor/f2bPL4CEtdsSLrGDxd4HKKKO6Gs=/0x0:1920x1080/1200x800/filters:focal(1035x326:1341x632)/cdn.vox-cdn.com/uploads/chorus_image/image/71812214/Ash_Ketchum_World_Champion_Screenshot_4.0.jpg"class="card-img-top" height="500px" width="500px" alt="..."/>
  <div class="card-body">
    <p class="card-text">pokemon collection</p>
    <a href="#" class="btn btn-primary"style={{color:"blue"}}> go somewhere</a>
  </div>
</div>


<div className="card" >
  <img src="https://ludoking.com/images/left.png" class="card-img-top" height="500px" width="500px" alt="..."/>
  <div class="card-body">
    <p class="card-text">luddo section</p>
    <a href="#" class="btn btn-primary"style={{color:"blue"}}> go somewhere</a>
  </div>
</div>


<div className="card" >
  <img src="https://upload.wikimedia.org/wikipedia/commons/thumb/7/71/Sector-coupling-800x566.jpg/1024px-Sector-coupling-800x566.jpg" class="card-img-top" height="500px" width="500px" alt="..."/>
  <div class="card-body">
    <p class="card-text"> spower section </p>
    <a href="#" class="btn btn-primary"style={{color:"blue"}}> go somewhere</a>
  </div>
</div>
</div>


<div class="d-flex">
      <div className="card" >
  <img src=" https://cdn.vox-cdn.com/thumbor/f2bPL4CEtdsSLrGDxd4HKKKO6Gs=/0x0:1920x1080/1200x800/filters:focal(1035x326:1341x632)/cdn.vox-cdn.com/uploads/chorus_image/image/71812214/Ash_Ketchum_World_Champion_Screenshot_4.0.jpg"class="card-img-top" height="500px" width="500px" alt="..."/>
  <div class="card-body">
    <p class="card-text">pokemon collection</p>
    <a href="#" class="btn btn-primary"style={{color:"blue"}}> go somewhere</a>
  </div>
</div>


<div className="card" >
  <img src="https://ludoking.com/images/left.png" class="card-img-top" height="500px" width="500px" alt="..."/>
  <div class="card-body">
    <p class="card-text">luddo section</p>
    <a href="#" class="btn btn-primary"style={{color:"blue"}}> go somewhere</a>
  </div>
</div>


<div className="card" >
  <img src="https://upload.wikimedia.org/wikipedia/commons/thumb/7/71/Sector-coupling-800x566.jpg/1024px-Sector-coupling-800x566.jpg" class="card-img-top" height="500px" width="500px" alt="..."/>
  <div class="card-body">
    <p class="card-text"> spower section </p>
    <a href="#" class="btn btn-primary"style={{color:"blue"}}> go somewhere</a>
  </div>
</div>
</div>

<div class="d-flex">
      <div className="card" >
  <img src=" https://cdn.vox-cdn.com/thumbor/f2bPL4CEtdsSLrGDxd4HKKKO6Gs=/0x0:1920x1080/1200x800/filters:focal(1035x326:1341x632)/cdn.vox-cdn.com/uploads/chorus_image/image/71812214/Ash_Ketchum_World_Champion_Screenshot_4.0.jpg"class="card-img-top" height="500px" width="500px" alt="..."/>
  <div class="card-body">
    <p class="card-text">pokemon collection</p>
    <a href="#" class="btn btn-primary"style={{color:"blue"}}> go somewhere</a>
  </div>
</div>


<div className="card" >
  <img src="https://ludoking.com/images/left.png" class="card-img-top" height="500px" width="500px" alt="..."/>
  <div class="card-body">
    <p class="card-text">luddo section</p>
    <a href="#" class="btn btn-primary"style={{color:"blue"}}> go somewhere</a>
  </div>
</div>


<div className="card" >
  <img src="https://upload.wikimedia.org/wikipedia/commons/thumb/7/71/Sector-coupling-800x566.jpg/1024px-Sector-coupling-800x566.jpg" class="card-img-top" height="500px" width="500px" alt="..."/>
  <div class="card-body">
    <p class="card-text"> spower section </p>
    <a href="#" class="btn btn-primary"style={{color:"blue"}}> go somewhere</a>
  </div>
</div>
</div>


<div class="d-flex">
      <div className="card" >
  <img src=" https://cdn.vox-cdn.com/thumbor/f2bPL4CEtdsSLrGDxd4HKKKO6Gs=/0x0:1920x1080/1200x800/filters:focal(1035x326:1341x632)/cdn.vox-cdn.com/uploads/chorus_image/image/71812214/Ash_Ketchum_World_Champion_Screenshot_4.0.jpg"class="card-img-top" height="500px" width="500px" alt="..."/>
  <div class="card-body">
    <p class="card-text">pokemon collection</p>
    <a href="#" class="btn btn-primary"style={{color:"blue"}}> go somewhere</a>
  </div>
</div>


<div className="card" >
  <img src="https://ludoking.com/images/left.png" class="card-img-top" height="500px" width="500px" alt="..."/>
  <div class="card-body">
    <p class="card-text">luddo section</p>
    <a href="#" class="btn btn-primary"style={{color:"blue"}}> go somewhere</a>
  </div>
</div>


<div className="card" >
  <img src="https://upload.wikimedia.org/wikipedia/commons/thumb/7/71/Sector-coupling-800x566.jpg/1024px-Sector-coupling-800x566.jpg" class="card-img-top" height="500px" width="500px" alt="..."/>
  <div class="card-body">
    <p class="card-text"> spower section </p>
    <a href="#" class="btn btn-primary"style={{color:"blue"}}> go somewhere</a>
  </div>
</div>
</div>


<div class="d-flex">
      <div className="card" >
  <img src=" https://cdn.vox-cdn.com/thumbor/f2bPL4CEtdsSLrGDxd4HKKKO6Gs=/0x0:1920x1080/1200x800/filters:focal(1035x326:1341x632)/cdn.vox-cdn.com/uploads/chorus_image/image/71812214/Ash_Ketchum_World_Champion_Screenshot_4.0.jpg"class="card-img-top" height="500px" width="500px" alt="..."/>
  <div class="card-body">
    <p class="card-text">pokemon collection</p>
    <a href="#" class="btn btn-primary"style={{color:"blue"}}> go somewhere</a>
  </div>
</div>


<div className="card" >
  <img src="https://ludoking.com/images/left.png" class="card-img-top" height="500px" width="500px" alt="..."/>
  <div class="card-body">
    <p class="card-text">luddo section</p>
    <a href="#" class="btn btn-primary"style={{color:"blue"}}> go somewhere</a>
  </div>
</div>


<div className="card" >
  <img src="https://upload.wikimedia.org/wikipedia/commons/thumb/7/71/Sector-coupling-800x566.jpg/1024px-Sector-coupling-800x566.jpg" class="card-img-top" height="500px" width="500px" alt="..."/>
  <div class="card-body">
    <p class="card-text"> spower section </p>
    <a href="#" class="btn btn-primary"style={{color:"blue"}}> go somewhere</a>
  </div>
</div>
</div>



<div class="d-flex">
      <div className="card" >
  <img src=" https://cdn.vox-cdn.com/thumbor/f2bPL4CEtdsSLrGDxd4HKKKO6Gs=/0x0:1920x1080/1200x800/filters:focal(1035x326:1341x632)/cdn.vox-cdn.com/uploads/chorus_image/image/71812214/Ash_Ketchum_World_Champion_Screenshot_4.0.jpg"class="card-img-top" height="500px" width="500px" alt="..."/>
  <div class="card-body">
    <p class="card-text">pokemon collection</p>
    <a href="#" class="btn btn-primary"style={{color:"blue"}}> go somewhere</a>
  </div>
</div>


<div className="card" >
  <img src="https://ludoking.com/images/left.png" class="card-img-top" height="500px" width="500px" alt="..."/>
  <div class="card-body">
    <p class="card-text">luddo section</p>
    <a href="#" class="btn btn-primary"style={{color:"blue"}}> go somewhere</a>
  </div>
</div>


<div className="card" >
  <img src="https://upload.wikimedia.org/wikipedia/commons/thumb/7/71/Sector-coupling-800x566.jpg/1024px-Sector-coupling-800x566.jpg" class="card-img-top" height="500px" width="500px" alt="..."/>
  <div class="card-body">
    <p class="card-text"> spower section </p>
    <a href="#" class="btn btn-primary"style={{color:"blue"}}> go somewhere</a>
  </div>
</div>
</div>


<div class="d-flex">
      <div className="card" >
  <img src=" https://cdn.vox-cdn.com/thumbor/f2bPL4CEtdsSLrGDxd4HKKKO6Gs=/0x0:1920x1080/1200x800/filters:focal(1035x326:1341x632)/cdn.vox-cdn.com/uploads/chorus_image/image/71812214/Ash_Ketchum_World_Champion_Screenshot_4.0.jpg"class="card-img-top" height="500px" width="500px" alt="..."/>
  <div class="card-body">
    <p class="card-text">pokemon collection</p>
    <a href="#" class="btn btn-primary"style={{color:"blue"}}> go somewhere</a>
  </div>
</div>


<div className="card" >
  <img src="https://ludoking.com/images/left.png" class="card-img-top" height="500px" width="500px" alt="..."/>
  <div class="card-body">
    <p class="card-text">luddo section</p>
    <a href="#" class="btn btn-primary"style={{color:"blue"}}> go somewhere</a>
  </div>
</div>


<div className="card" >
  <img src="https://upload.wikimedia.org/wikipedia/commons/thumb/7/71/Sector-coupling-800x566.jpg/1024px-Sector-coupling-800x566.jpg" class="card-img-top" height="500px" width="500px" alt="..."/>
  <div class="card-body">
    <p class="card-text"> spower section </p>
    <a href="#" class="btn btn-primary"style={{color:"blue"}}> go somewhere</a>
  </div>
</div>
</div>



<div class="d-flex">
      <div className="card" >
  <img src=" https://cdn.vox-cdn.com/thumbor/f2bPL4CEtdsSLrGDxd4HKKKO6Gs=/0x0:1920x1080/1200x800/filters:focal(1035x326:1341x632)/cdn.vox-cdn.com/uploads/chorus_image/image/71812214/Ash_Ketchum_World_Champion_Screenshot_4.0.jpg"class="card-img-top" height="500px" width="500px" alt="..."/>
  <div class="card-body">
    <p class="card-text">pokemon collection</p>
    <a href="#" class="btn btn-primary"style={{color:"blue"}}> go somewhere</a>
  </div>
</div>


<div className="card" >
  <img src="https://ludoking.com/images/left.png" class="card-img-top" height="500px" width="500px" alt="..."/>
  <div class="card-body">
    <p class="card-text">luddo section</p>
    <a href="#" class="btn btn-primary"style={{color:"blue"}}> go somewhere</a>
  </div>
</div>


<div className="card" >
  <img src="https://upload.wikimedia.org/wikipedia/commons/thumb/7/71/Sector-coupling-800x566.jpg/1024px-Sector-coupling-800x566.jpg" class="card-img-top" height="500px" width="500px" alt="..."/>
  <div class="card-body">
    <p class="card-text"> spower section </p>
    <a href="#" class="btn btn-primary"style={{color:"blue"}}> go somewhere</a>
  </div>
</div>
</div>


<div class="d-flex">
      <div className="card" >
  <img src=" https://cdn.vox-cdn.com/thumbor/f2bPL4CEtdsSLrGDxd4HKKKO6Gs=/0x0:1920x1080/1200x800/filters:focal(1035x326:1341x632)/cdn.vox-cdn.com/uploads/chorus_image/image/71812214/Ash_Ketchum_World_Champion_Screenshot_4.0.jpg"class="card-img-top" height="500px" width="500px" alt="..."/>
  <div class="card-body">
    <p class="card-text">pokemon collection</p>
    <a href="#" class="btn btn-primary"style={{color:"blue"}}> go somewhere</a>
  </div>
</div>


<div className="card" >
  <img src="https://ludoking.com/images/left.png" class="card-img-top" height="500px" width="500px" alt="..."/>
  <div class="card-body">
    <p class="card-text">luddo section</p>
    <a href="#" class="btn btn-primary"style={{color:"blue"}}> go somewhere</a>
  </div>
</div>


<div className="card" >
  <img src="https://upload.wikimedia.org/wikipedia/commons/thumb/7/71/Sector-coupling-800x566.jpg/1024px-Sector-coupling-800x566.jpg" class="card-img-top" height="500px" width="500px" alt="..."/>
  <div class="card-body">
    <p class="card-text"> spower section </p>
    <a href="#" class="btn btn-primary"style={{color:"blue"}}> go somewhere</a>
  </div>
</div>
</div>


<div class="d-flex">
      <div className="card" >
  <img src=" https://cdn.vox-cdn.com/thumbor/f2bPL4CEtdsSLrGDxd4HKKKO6Gs=/0x0:1920x1080/1200x800/filters:focal(1035x326:1341x632)/cdn.vox-cdn.com/uploads/chorus_image/image/71812214/Ash_Ketchum_World_Champion_Screenshot_4.0.jpg"class="card-img-top" height="500px" width="500px" alt="..."/>
  <div class="card-body">
    <p class="card-text">pokemon collection</p>
    <a href="#" class="btn btn-primary"style={{color:"blue"}}> go somewhere</a>
  </div>
</div>


<div className="card" >
  <img src="https://ludoking.com/images/left.png" class="card-img-top" height="500px" width="500px" alt="..."/>
  <div class="card-body">
    <p class="card-text">luddo section</p>
    <a href="#" class="btn btn-primary"style={{color:"blue"}}> go somewhere</a>
  </div>
</div>


<div className="card" >
  <img src="https://upload.wikimedia.org/wikipedia/commons/thumb/7/71/Sector-coupling-800x566.jpg/1024px-Sector-coupling-800x566.jpg" class="card-img-top" height="500px" width="500px" alt="..."/>
  <div class="card-body">
    <p class="card-text"> spower section </p>
    <a href="#" class="btn btn-primary"style={{color:"blue"}}> go somewhere</a>
  </div>
</div>
</div>


<div class="d-flex">
      <div className="card" >
  <img src=" https://cdn.vox-cdn.com/thumbor/f2bPL4CEtdsSLrGDxd4HKKKO6Gs=/0x0:1920x1080/1200x800/filters:focal(1035x326:1341x632)/cdn.vox-cdn.com/uploads/chorus_image/image/71812214/Ash_Ketchum_World_Champion_Screenshot_4.0.jpg"class="card-img-top" height="500px" width="500px" alt="..."/>
  <div class="card-body">
    <p class="card-text">pokemon collection</p>
    <a href="#" class="btn btn-primary"style={{color:"blue"}}> go somewhere</a>
  </div>
</div>


<div className="card" >
  <img src="https://ludoking.com/images/left.png" class="card-img-top" height="500px" width="500px" alt="..."/>
  <div class="card-body">
    <p class="card-text">luddo section</p>
    <a href="#" class="btn btn-primary"style={{color:"blue"}}> go somewhere</a>
  </div>
</div>


<div className="card" >
  <img src="https://upload.wikimedia.org/wikipedia/commons/thumb/7/71/Sector-coupling-800x566.jpg/1024px-Sector-coupling-800x566.jpg" class="card-img-top" height="500px" width="500px" alt="..."/>
  <div class="card-body">
    <p class="card-text"> spower section </p>
    <a href="#" class="btn btn-primary"style={{color:"blue"}}> go somewhere</a>
  </div>
</div>
</div>

<div class="d-flex">
      <div className="card" >
  <img src=" https://cdn.vox-cdn.com/thumbor/f2bPL4CEtdsSLrGDxd4HKKKO6Gs=/0x0:1920x1080/1200x800/filters:focal(1035x326:1341x632)/cdn.vox-cdn.com/uploads/chorus_image/image/71812214/Ash_Ketchum_World_Champion_Screenshot_4.0.jpg"class="card-img-top" height="500px" width="500px" alt="..."/>
  <div class="card-body">
    <p class="card-text">pokemon collection</p>
    <a href="#" class="btn btn-primary"style={{color:"blue"}}> go somewhere</a>
  </div>
</div>


<div className="card" >
  <img src="https://ludoking.com/images/left.png" class="card-img-top" height="500px" width="500px" alt="..."/>
  <div class="card-body">
    <p class="card-text">luddo section</p>
    <a href="#" class="btn btn-primary"style={{color:"blue"}}> go somewhere</a>
  </div>
</div>


<div className="card" >
  <img src="https://upload.wikimedia.org/wikipedia/commons/thumb/7/71/Sector-coupling-800x566.jpg/1024px-Sector-coupling-800x566.jpg" class="card-img-top" height="500px" width="500px" alt="..."/>
  <div class="card-body">
    <p class="card-text"> spower section </p>
    <a href="#" class="btn btn-primary"style={{color:"blue"}}> go somewhere</a>
  </div>
</div>
</div>


<div class="d-flex">
      <div className="card" >
  <img src=" https://cdn.vox-cdn.com/thumbor/f2bPL4CEtdsSLrGDxd4HKKKO6Gs=/0x0:1920x1080/1200x800/filters:focal(1035x326:1341x632)/cdn.vox-cdn.com/uploads/chorus_image/image/71812214/Ash_Ketchum_World_Champion_Screenshot_4.0.jpg"class="card-img-top" height="500px" width="500px" alt="..."/>
  <div class="card-body">
    <p class="card-text">pokemon collection</p>
    <a href="#" class="btn btn-primary"style={{color:"blue"}}> go somewhere</a>
  </div>
</div>


<div className="card" >
  <img src="https://ludoking.com/images/left.png" class="card-img-top" height="500px" width="500px" alt="..."/>
  <div class="card-body">
    <p class="card-text">luddo section</p>
    <a href="#" class="btn btn-primary"style={{color:"blue"}}> go somewhere</a>
  </div>
</div>


<div className="card" >
  <img src="https://upload.wikimedia.org/wikipedia/commons/thumb/7/71/Sector-coupling-800x566.jpg/1024px-Sector-coupling-800x566.jpg" class="card-img-top" height="500px" width="500px" alt="..."/>
  <div class="card-body">
    <p class="card-text"> spower section </p>
    <a href="#" class="btn btn-primary"style={{color:"blue"}}> go somewhere</a>
  </div>
</div>
</div>

<div class="d-flex">
      <div className="card" >
  <img src=" https://cdn.vox-cdn.com/thumbor/f2bPL4CEtdsSLrGDxd4HKKKO6Gs=/0x0:1920x1080/1200x800/filters:focal(1035x326:1341x632)/cdn.vox-cdn.com/uploads/chorus_image/image/71812214/Ash_Ketchum_World_Champion_Screenshot_4.0.jpg"class="card-img-top" height="500px" width="500px" alt="..."/>
  <div class="card-body">
    <p class="card-text">pokemon collection</p>
    <a href="#" class="btn btn-primary"style={{color:"blue"}}> go somewhere</a>
  </div>
</div>


<div className="card" >
  <img src="https://ludoking.com/images/left.png" class="card-img-top" height="500px" width="500px" alt="..."/>
  <div class="card-body">
    <p class="card-text">luddo section</p>
    <a href="#" class="btn btn-primary"style={{color:"blue"}}> go somewhere</a>
  </div>
</div>


<div className="card" >
  <img src="https://upload.wikimedia.org/wikipedia/commons/thumb/7/71/Sector-coupling-800x566.jpg/1024px-Sector-coupling-800x566.jpg" class="card-img-top" height="500px" width="500px" alt="..."/>
  <div class="card-body">
    <p class="card-text"> spower section </p>
    <a href="#" class="btn btn-primary"style={{color:"blue"}}> go somewhere</a>
  </div>
</div>
</div>


<div class="d-flex">
      <div className="card" >
  <img src=" https://cdn.vox-cdn.com/thumbor/f2bPL4CEtdsSLrGDxd4HKKKO6Gs=/0x0:1920x1080/1200x800/filters:focal(1035x326:1341x632)/cdn.vox-cdn.com/uploads/chorus_image/image/71812214/Ash_Ketchum_World_Champion_Screenshot_4.0.jpg"class="card-img-top" height="500px" width="500px" alt="..."/>
  <div class="card-body">
    <p class="card-text">pokemon collection</p>
    <a href="#" class="btn btn-primary"style={{color:"blue"}}> go somewhere</a>
  </div>
</div>


<div className="card" >
  <img src="https://ludoking.com/images/left.png" class="card-img-top" height="500px" width="500px" alt="..."/>
  <div class="card-body">
    <p class="card-text">luddo section</p>
    <a href="#" class="btn btn-primary"style={{color:"blue"}}> go somewhere</a>
  </div>
</div>


<div className="card" >
  <img src="https://upload.wikimedia.org/wikipedia/commons/thumb/7/71/Sector-coupling-800x566.jpg/1024px-Sector-coupling-800x566.jpg" class="card-img-top" height="500px" width="500px" alt="..."/>
  <div class="card-body">
    <p class="card-text"> spower section </p>
    <a href="#" class="btn btn-primary"style={{color:"blue"}}> go somewhere</a>
  </div>
</div>
</div>


<div class="d-flex">
      <div className="card" >
  <img src=" https://cdn.vox-cdn.com/thumbor/f2bPL4CEtdsSLrGDxd4HKKKO6Gs=/0x0:1920x1080/1200x800/filters:focal(1035x326:1341x632)/cdn.vox-cdn.com/uploads/chorus_image/image/71812214/Ash_Ketchum_World_Champion_Screenshot_4.0.jpg"class="card-img-top" height="500px" width="500px" alt="..."/>
  <div class="card-body">
    <p class="card-text">pokemon collection</p>
    <a href="#" class="btn btn-primary"style={{color:"blue"}}> go somewhere</a>
  </div>
</div>


<div className="card" >
  <img src="https://ludoking.com/images/left.png" class="card-img-top" height="500px" width="500px" alt="..."/>
  <div class="card-body">
    <p class="card-text">luddo section</p>
    <a href="#" class="btn btn-primary"style={{color:"blue"}}> go somewhere</a>
  </div>
</div>


<div className="card" >
  <img src="https://upload.wikimedia.org/wikipedia/commons/thumb/7/71/Sector-coupling-800x566.jpg/1024px-Sector-coupling-800x566.jpg" class="card-img-top" height="500px" width="500px" alt="..."/>
  <div class="card-body">
    <p class="card-text"> spower section </p>
    <a href="#" class="btn btn-primary"style={{color:"blue"}}> go somewhere</a>
  </div>
</div>
</div>


<div class="d-flex">
      <div className="card" >
  <img src=" https://cdn.vox-cdn.com/thumbor/f2bPL4CEtdsSLrGDxd4HKKKO6Gs=/0x0:1920x1080/1200x800/filters:focal(1035x326:1341x632)/cdn.vox-cdn.com/uploads/chorus_image/image/71812214/Ash_Ketchum_World_Champion_Screenshot_4.0.jpg"class="card-img-top" height="500px" width="500px" alt="..."/>
  <div class="card-body">
    <p class="card-text">pokemon collection</p>
    <a href="#" class="btn btn-primary"style={{color:"blue"}}> go somewhere</a>
  </div>
</div>


<div className="card" >
  <img src="https://ludoking.com/images/left.png" class="card-img-top" height="500px" width="500px" alt="..."/>
  <div class="card-body">
    <p class="card-text">luddo section</p>
    <a href="#" class="btn btn-primary"style={{color:"blue"}}> go somewhere</a>
  </div>
</div>


<div className="card" >
  <img src="https://upload.wikimedia.org/wikipedia/commons/thumb/7/71/Sector-coupling-800x566.jpg/1024px-Sector-coupling-800x566.jpg" class="card-img-top" height="500px" width="500px" alt="..."/>
  <div class="card-body">
    <p class="card-text"> spower section </p>
    <a href="#" class="btn btn-primary"style={{color:"blue"}}> go somewhere</a>
  </div>
</div>
</div>


<div class="d-flex">
      <div className="card" >
  <img src=" https://cdn.vox-cdn.com/thumbor/f2bPL4CEtdsSLrGDxd4HKKKO6Gs=/0x0:1920x1080/1200x800/filters:focal(1035x326:1341x632)/cdn.vox-cdn.com/uploads/chorus_image/image/71812214/Ash_Ketchum_World_Champion_Screenshot_4.0.jpg"class="card-img-top" height="500px" width="500px" alt="..."/>
  <div class="card-body">
    <p class="card-text">pokemon collection</p>
    <a href="#" class="btn btn-primary"style={{color:"blue"}}> go somewhere</a>
  </div>
</div>


<div className="card" >
  <img src="https://ludoking.com/images/left.png" class="card-img-top" height="500px" width="500px" alt="..."/>
  <div class="card-body">
    <p class="card-text">luddo section</p>
    <a href="#" class="btn btn-primary"style={{color:"blue"}}> go somewhere</a>
  </div>
</div>


<div className="card" >
  <img src="https://upload.wikimedia.org/wikipedia/commons/thumb/7/71/Sector-coupling-800x566.jpg/1024px-Sector-coupling-800x566.jpg" class="card-img-top" height="500px" width="500px" alt="..."/>
  <div class="card-body">
    <p class="card-text"> spower section </p>
    <a href="#" class="btn btn-primary"style={{color:"blue"}}> go somewhere</a>
  </div>
</div>
</div>


<div class="d-flex">
      <div className="card" >
  <img src=" https://cdn.vox-cdn.com/thumbor/f2bPL4CEtdsSLrGDxd4HKKKO6Gs=/0x0:1920x1080/1200x800/filters:focal(1035x326:1341x632)/cdn.vox-cdn.com/uploads/chorus_image/image/71812214/Ash_Ketchum_World_Champion_Screenshot_4.0.jpg"class="card-img-top" height="500px" width="500px" alt="..."/>
  <div class="card-body">
    <p class="card-text">pokemon collection</p>
    <a href="#" class="btn btn-primary"style={{color:"blue"}}> go somewhere</a>
  </div>
</div>


<div className="card" >
  <img src="https://ludoking.com/images/left.png" class="card-img-top" height="500px" width="500px" alt="..."/>
  <div class="card-body">
    <p class="card-text">luddo section</p>
    <a href="#" class="btn btn-primary"style={{color:"blue"}}> go somewhere</a>
  </div>
</div>


<div className="card" >
  <img src="https://upload.wikimedia.org/wikipedia/commons/thumb/7/71/Sector-coupling-800x566.jpg/1024px-Sector-coupling-800x566.jpg" class="card-img-top" height="500px" width="500px" alt="..."/>
  <div class="card-body">
    <p class="card-text"> spower section </p>
    <a href="#" class="btn btn-primary"style={{color:"blue"}}> go somewhere</a>
  </div>
</div>
</div>


<div class="d-flex">
      <div className="card" >
  <img src=" https://cdn.vox-cdn.com/thumbor/f2bPL4CEtdsSLrGDxd4HKKKO6Gs=/0x0:1920x1080/1200x800/filters:focal(1035x326:1341x632)/cdn.vox-cdn.com/uploads/chorus_image/image/71812214/Ash_Ketchum_World_Champion_Screenshot_4.0.jpg"class="card-img-top" height="500px" width="500px" alt="..."/>
  <div class="card-body">
    <p class="card-text">pokemon collection</p>
    <a href="#" class="btn btn-primary"style={{color:"blue"}}> go somewhere</a>
  </div>
</div>


<div className="card" >
  <img src="https://ludoking.com/images/left.png" class="card-img-top" height="500px" width="500px" alt="..."/>
  <div class="card-body">
    <p class="card-text">luddo section</p>
    <a href="#" class="btn btn-primary"style={{color:"blue"}}> go somewhere</a>
  </div>
</div>


<div className="card" >
  <img src="https://upload.wikimedia.org/wikipedia/commons/thumb/7/71/Sector-coupling-800x566.jpg/1024px-Sector-coupling-800x566.jpg" class="card-img-top" height="500px" width="500px" alt="..."/>
  <div class="card-body">
    <p class="card-text"> spower section </p>
    <a href="#" class="btn btn-primary"style={{color:"blue"}}> go somewhere</a>
  </div>
</div>
</div>

<div class="d-flex">
      <div className="card" >
  <img src=" https://cdn.vox-cdn.com/thumbor/f2bPL4CEtdsSLrGDxd4HKKKO6Gs=/0x0:1920x1080/1200x800/filters:focal(1035x326:1341x632)/cdn.vox-cdn.com/uploads/chorus_image/image/71812214/Ash_Ketchum_World_Champion_Screenshot_4.0.jpg"class="card-img-top" height="500px" width="500px" alt="..."/>
  <div class="card-body">
    <p class="card-text">pokemon collection</p>
    <a href="#" class="btn btn-primary"style={{color:"blue"}}> go somewhere</a>
  </div>
</div>


<div className="card" >
  <img src="https://ludoking.com/images/left.png" class="card-img-top" height="500px" width="500px" alt="..."/>
  <div class="card-body">
    <p class="card-text">luddo section</p>
    <a href="#" class="btn btn-primary"style={{color:"blue"}}> go somewhere</a>
  </div>
</div>


<div className="card" >
  <img src="https://upload.wikimedia.org/wikipedia/commons/thumb/7/71/Sector-coupling-800x566.jpg/1024px-Sector-coupling-800x566.jpg" class="card-img-top" height="500px" width="500px" alt="..."/>
  <div class="card-body">
    <p class="card-text"> spower section </p>
    <a href="#" class="btn btn-primary"style={{color:"blue"}}> go somewhere</a>
  </div>
</div>
</div>





    </div>
  )
}

export default Service
