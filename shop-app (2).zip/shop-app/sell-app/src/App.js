import {Route , Routes} from "react-router-dom";

import Home from "./Home";

import About from "./About";
import Service from"./Service";
import Contact from "./Contact";
import Navbar from "./Navbar";

import './index.css';
function App() {
   
    return(
      <>
      <Navbar />

      
  <Routes>
    <Route path="/" element={<Home></Home>}/>
    <Route path="/About" element={<About></About>}/>
    <Route path="Service"element={<Service></Service>}/>
    <Route path="/Contact" element={<Contact></Contact>}/>
    
    

  </Routes>
  
     
     
      </>
    )

}
export default App; 